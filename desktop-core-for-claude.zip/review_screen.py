"""
Anki Occlusion — PDF & Image Flashcard App  v19 (Smart Review Items Rebuild)
================================================
v19 New Feature:
  [SMART REVIEW REBUILD] ReviewScreen ab sirf tabhi _items list rebuild karta hai
      jab editor mein koi box ka group_id actually change hua ho.
      Bina kisi change ke review se editor aur wapas = zero overhead.
      Sirf affected card ke items replace hote hain — baaki cards untouched.
      Detection: before/after snapshot of {box_id -> group_id} map.

v18 (Hardware Mask Cache + LRU Page Cache Edition)
================================================
v18 New Features:
  [HARDWARE MASK CACHE] OcclusionCanvas ab masks ko ek GPU-backed QPixmap
      offscreen layer mein cache karta hai. Jab tak koi mask change nahi hota,
      paintEvent mein sirf ek drawPixmap() call hota hai — loop nahi.
      100+ masks = 1 mask jaisi speed. FPS ~3x better on dense cards.
      Cache sirf tab rebuild hota hai jab _mask_cache_dirty = True ho:
        - mouseReleaseEvent (drag/draw finish)
        - delete, undo, redo, label change, group/ungroup
      Mouse drag ke dauran cache rebuild NAHI hoti — isliye dragging bhi smooth.

  [LRU PAGE CACHE] GLOBAL_PDF_CACHE replace ho gaya ek smart LRUPageCache se.
      Pura combined QPixmap store karne ki jagah ab individual pages store hoti hain.
      Max 15 pages RAM mein — baaki on-demand fitz se reload.
      Ek 100-page PDF pehle ~2GB RAM leta tha, ab sirf ~300MB.
      OrderedDict se O(1) get/put/evict — zero performance penalty.

v17 New Feature:
  [PROGRESSIVE LOADING] PDF ab 10-10 pages ke chunks mein load hota hai.
      Pehla chunk (10 pages) aate hi canvas pe dikhta hai — user turant
      kaam shuru kar sakta hai. Baaki pages background mein silently load
      hote rehte hain. Progress bar-style label dikhata hai kitne pages load hue.
  [ULTRA FAST CACHE] PDF ek baar load hone ke baad RAM mein save ho jati hai.
      Edit aur Review mode ke beech switch karne par zero delay (0.001s).
v16 Bug Fixes:
  [NOT-RESPONDING FIX] PDF ab background QThread mein load hota hai.
      CardEditorDialog._load_card() aur _load_pdf() dono ab non-blocking hain.
      _reload_pdf() (Live Sync) bhi thread-based ho gaya.
      closeEvent/reject mein thread safely stop hota hai.
v15 Bug Fixes:
  [FIX-1]  ReviewScreen.__init__ — duplicate item prevention
  [FIX-2]  _rate() — "reviews" double-increment fixed
  [FIX-3]  _start_review() — win.closeEvent double-save fixed
  [FIX-4]  is_due_today() called on un-initialised boxes in ReviewScreen
  [FIX-5]  Group dedup across cards
  [LAG-FIX] Native Hardware Painting & Caching applied to OcclusionCanvas
            to eliminate mouseMoveEvent lag completely.
"""

from sm2_engine import (
    sched_init,
    sm2_init,
    sched_update,
    sm2_update,
    is_due_now,
    is_due_today,
    sm2_is_due,
    sm2_days_left,
    _fmt_due_interval,
    sm2_simulate,
    sm2_badge,
)

# Daily Journal — safe import
try:
    from ui.journal import JournalDialog

    _JOURNAL_AVAILABLE = True
except ImportError:
    _JOURNAL_AVAILABLE = False

# Session Timer — safe import
try:
    from session_timer import SessionTimer

    _TIMER_AVAILABLE = True
except ImportError:
    _TIMER_AVAILABLE = False

from pdf_engine import (
    PDF_SUPPORT,
    PAGE_CACHE,
    PdfLoaderThread,
    PdfSkeletonThread,
    pdf_page_to_pixmap,
    load_pdf_skeleton,
    PdfOnDemandThread,
    build_skeleton_placeholders,
    invalidate_pdf_skeleton,  # STEP 2 + 3
    choose_pdf_render_zoom,
    ensure_pdf_cache_profile,
    adapt_pdf_boxes_to_render_zoom,
    PDF_LEGACY_BOX_ZOOM,
    get_cached_pdf_page_set,
)

from editor_ui import OcclusionCanvas, _ZoomableScrollArea
from ui.editor_dialog import CardEditorDialog
from ui.pdf_annotation_dialog import PdfAnnotationDialog
from ui.pdf_viewer_controller import PdfViewerController
from services import shortcut_manager

import fitz

from data_manager import (
    load_data,
    save_data,
    find_deck_by_id,
    next_deck_id,
    new_box_id,
    deck_history,
    DATA_FILE,
    store,
)
from perf_utils import get_pdf_page_count
from storage_paths import resolve_asset_path

import sys, os, copy, uuid, math, time
from datetime import datetime, date, timedelta


from PyQt5.QtWidgets import (
    QApplication,
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QPushButton,
    QLabel,
    QFileDialog,
    QListWidget,
    QListWidgetItem,
    QFrame,
    QScrollArea,
    QInputDialog,
    QMessageBox,
    QSplitter,
    QStatusBar,
    QProgressBar,
    QDialog,
    QFormLayout,
    QLineEdit,
    QTextEdit,
    QSizePolicy,
    QTreeWidget,
    QTreeWidgetItem,
    QAbstractItemView,
    QMenu,
    QStyledItemDelegate,
    QStyle,
    QHeaderView,
    QShortcut,
)
from PyQt5.QtCore import (
    Qt,
    QRect,
    QPoint,
    QSize,
    QRectF,
    QPointF,
    pyqtSignal,
    QTimer,
    QModelIndex,
    QFileSystemWatcher,
    QThread,
    QEvent,
    QMimeData,
    QByteArray,
    QUrl,
    QSettings,
)
from PyQt5.QtGui import QGuiApplication as _QGA
from PyQt5.QtGui import (
    QPainter,
    QPen,
    QColor,
    QPixmap,
    QFont,
    QCursor,
    QIcon,
    QBrush,
    QTransform,
    QPainterPath,
    QDrag,
    QDesktopServices,
    QKeySequence,
)

# ═══════════════════════════════════════════════════════════════════════════════
#  THEME
# ═══════════════════════════════════════════════════════════════════════════════

# ── Theme constants — single source of truth is theme_manager.PALETTES["dark"] ──
from theme_manager import get_palette as _get_palette

_DARK = _get_palette("dark")
C_BG = _DARK["C_BG"]
C_SURFACE = _DARK["C_SURFACE"]
C_CARD = _DARK["C_CARD"]
C_ACCENT = _DARK["C_ACCENT"]
C_GREEN = _DARK["C_GREEN"]
C_RED = _DARK["C_RED"]
C_YELLOW = _DARK["C_YELLOW"]
C_TEXT = _DARK["C_TEXT"]
C_SUBTEXT = _DARK["C_SUBTEXT"]
C_BORDER = _DARK["C_BORDER"]
C_MASK = "#F7916A"
C_GROUP = "#BD93F9"


BASE_FONT_SIZE = 11


def _build_ss(font_size: int = BASE_FONT_SIZE) -> str:
    return f"""
QMainWindow,QDialog{{background:{C_BG};color:{C_TEXT};}}
QWidget{{background:{C_BG};color:{C_TEXT};font-family:'Segoe UI';font-size:{font_size}px;}}
QFrame{{background:{C_SURFACE};border-radius:8px;}}
QLabel{{background:transparent;color:{C_TEXT};}}
QPushButton{{background:{C_ACCENT};color:white;border:none;border-radius:8px;padding:8px 18px;font-weight:bold;}}
QPushButton:hover{{background:#6A58E0;}}
QPushButton:pressed{{background:#5448C8;}}
QPushButton#danger{{background:{C_RED};color:white;}}
QPushButton#danger:hover{{background:#CC3333;}}
QPushButton#success{{background:{C_GREEN};color:#1E1E2E;}}
QPushButton#success:hover{{background:#3DD668;}}
QPushButton#warning{{background:{C_YELLOW};color:#1E1E2E;}}
QPushButton#warning:hover{{background:#D9E070;}}
QPushButton#hard{{background:#E08030;color:white;}}
QPushButton#hard:hover{{background:#C06020;}}
QPushButton#flat{{background:{C_CARD};color:{C_TEXT};border:1px solid {C_BORDER};}}
QPushButton#flat:hover{{background:{C_SURFACE};}}
QListWidget,QTreeWidget{{background:{C_SURFACE};border:1px solid {C_BORDER};border-radius:8px;padding:4px;}}
QListWidget::item,QTreeWidget::item{{padding:6px;border-radius:6px;}}
QListWidget::item:selected,QTreeWidget::item:selected{{background:{C_ACCENT};color:white;}}
QListWidget::item:hover,QTreeWidget::item:hover{{background:{C_CARD};}}
QTreeView::drop-indicator{{background:{C_ACCENT};height:3px;border:none;border-radius:2px;}}
QScrollArea{{border:none;background:transparent;}}
QScrollBar:vertical{{background:{C_SURFACE};width:8px;border-radius:4px;}}
QScrollBar::handle:vertical{{background:{C_BORDER};border-radius:4px;}}
QLineEdit,QTextEdit{{background:{C_CARD};color:{C_TEXT};border:1px solid {C_BORDER};border-radius:6px;padding:6px;}}
QProgressBar{{background:{C_CARD};border-radius:6px;height:12px;text-align:center;color:transparent;}}
QProgressBar::chunk{{background:{C_ACCENT};border-radius:6px;}}
QMessageBox{{background:{C_BG};color:{C_TEXT};}}
QStatusBar{{background:{C_SURFACE};color:{C_SUBTEXT};}}
QMenu{{background:{C_SURFACE};color:{C_TEXT};border:1px solid {C_BORDER};border-radius:6px;}}
QMenu::item:selected{{background:{C_ACCENT};}}
"""


SS = _build_ss()


# ═══════════════════════════════════════════════════════════════════════════════
#  NINJA DOJO THEME PALETTE  (matches test.html / dojo theme)
# ═══════════════════════════════════════════════════════════════════════════════

DOJO = {
    "bg": "#07070B",
    "surface": "#0F0F17",
    "card": "#14141F",
    "accent": "#72FF4F",  # neon green
    "accent2": "#A86CFF",  # purple
    "green": "#72FF4F",
    "red": "#FF4444",
    "yellow": "#FFD700",
    "text": "#E0E0FF",
    "subtext": "#5F627D",
    "border": "#1A1A26",
    "font": "'Orbitron', 'Share Tech Mono', monospace",
    "font_body": "'Rajdhani', 'Segoe UI', sans-serif",
}


def _is_dojo() -> bool:
    """Return True if the Ninja Dojo theme is currently active."""
    app = QApplication.instance()
    return getattr(app, "_active_theme", "classic") in ["dojo", "tmnt"]


def _tc(classic_val: str, dojo_val: str) -> str:
    """Theme-conditional: return dojo_val if dojo active, else classic_val."""
    return dojo_val if _is_dojo() else classic_val


# ═══════════════════════════════════════════════════════════════════════════════
#  REVIEW SCREEN
# ═══════════════════════════════════════════════════════════════════════════════

QUEUE_ROLE = Qt.UserRole + 10
QUEUE_INDEX_ROLE = Qt.UserRole + 11
CARD_DRAG_MIME = "application/x-anki-card"


class QueueDelegate(QStyledItemDelegate):
    # Classic colors
    COLORS = {
        "current": {"bg": QColor(C_GREEN), "fg": QColor("#1E1E2E")},
        "done": {"bg": QColor("#2A3A2A"), "fg": QColor("#6A8A6A")},
        "pending": {"bg": QColor(C_SURFACE), "fg": QColor(C_TEXT)},
        "relearn": {"bg": QColor("#3A2A1A"), "fg": QColor("#E08030")},
        "peek": {"bg": QColor("#B83B3B"), "fg": QColor("#FFF1F1")},
    }

    def __init__(self, parent=None):
        super().__init__(parent)
        self._cached_theme = None
        self._cached_cols = None

    def _get_cols(self, theme: str, state: str) -> dict:
        # Rebuild color map only when theme changes — not every paint call
        if theme != self._cached_theme:
            from theme_manager import get_palette

            self._cached_theme = theme
            if theme in ("dojo", "tmnt"):
                p = get_palette(theme)
                self._cached_cols = {
                    "current": {"bg": QColor(p["C_ACCENT"]), "fg": QColor(p["C_BG"])},
                    "done": {
                        "bg": QColor("#0A0A12" if theme == "dojo" else p["C_CARD"]),
                        "fg": QColor("#3A3A5A" if theme == "dojo" else p["C_SUBTEXT"]),
                    },
                    "pending": {
                        "bg": QColor(p["C_SURFACE"]),
                        "fg": QColor(p["C_TEXT"]),
                    },
                    "relearn": {
                        "bg": QColor(
                            "#1A0A05"
                            if theme == "dojo"
                            else p.get("C_ORANGE", "#FF8040")
                        ),
                        "fg": QColor(
                            "#FF8040" if theme == "dojo" else p.get("C_BG", "#000")
                        ),
                    },
                    "peek": {
                        "bg": QColor("#2A0505" if theme == "dojo" else p["C_RED"]),
                        "fg": QColor("#FF6060" if theme == "dojo" else p["C_BG"]),
                    },
                }
            else:
                self._cached_cols = self.COLORS
        return self._cached_cols[state]

    def paint(self, painter, option, index):
        app = QApplication.instance()
        theme = getattr(app, "_active_theme", "classic")
        state = index.data(QUEUE_ROLE) or "pending"
        cols = self._get_cols(theme, state)

        painter.save()
        r = option.rect.adjusted(2, 2, -2, -2)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setPen(Qt.NoPen)
        painter.setBrush(QBrush(cols["bg"]))
        painter.drawRoundedRect(r, 5, 5)
        if state == "current":
            painter.setBrush(QBrush(QColor("#1E1E2E")))
            painter.drawRect(r.left(), r.top() + 4, 4, r.height() - 8)
        painter.setPen(cols["fg"])
        font = painter.font()
        font.setBold(state == "current")
        painter.setFont(font)
        painter.drawText(r.adjusted(10, 0, -4, 0), Qt.AlignVCenter, index.data())
        painter.restore()

    def sizeHint(self, option, index):
        return QSize(0, 34)


class ReviewScreen(QWidget):
    finished = pyqtSignal()
    cancelled = pyqtSignal()
    QUEUE_AUTO_HIDE_MS = 2000
    PRIORITY_PAGE_LIMIT = 16
    FLOATING_TIMER_SESSION_FONT_PX = 36
    FLOATING_TIMER_TODAY_FONT_PX = 30

    RATINGS = [
        ("1  🔁 Again", "danger", 1),
        ("2  😓 Hard", "hard", 3),
        ("3  ✅ Good", "success", 4),
        ("4  ⚡ Easy", "warning", 5),
        ("5  ⭐ Perfect", "perfect", 6),
    ]
    RATING_SHORTCUTS = {
        Qt.Key_1: 1,
        Qt.Key_2: 3,
        Qt.Key_3: 4,
        Qt.Key_4: 5,
        Qt.Key_5: 6,
    }
    RATING_SHORTCUT_ACTIONS = (
        ("review.rate_again", 1),
        ("review.rate_hard", 3),
        ("review.rate_good", 4),
        ("review.rate_easy", 5),
        ("review.rate_perfect", 6),
    )
    RATING_LABELS = ["Again", "Hard", "Good", "Easy", "Perfect"]

    @property
    def _items(self):
        return self.mgr._items

    @_items.setter
    def _items(self, val):
        self.mgr._items = val

    @property
    def _idx(self):
        return self.mgr._idx

    @_idx.setter
    def _idx(self, val):
        self.mgr._idx = val

    @property
    def _done(self):
        return self.mgr._done

    @_done.setter
    def _done(self, val):
        self.mgr._done = val

    @property
    def _queued_ids(self):
        return self.mgr._queued_ids

    @_queued_ids.setter
    def _queued_ids(self, val):
        self.mgr._queued_ids = val

    @property
    def _deleted_ids(self):
        return self.mgr._deleted_ids

    @_deleted_ids.setter
    def _deleted_ids(self, val):
        self.mgr._deleted_ids = val

    @property
    def _review_undo_stack(self):
        return self.mgr._review_undo_stack

    @_review_undo_stack.setter
    def _review_undo_stack(self, val):
        self.mgr._review_undo_stack = val

    @property
    def _review_redo_stack(self):
        return self.mgr._review_redo_stack

    @_review_redo_stack.setter
    def _review_redo_stack(self, val):
        self.mgr._review_redo_stack = val

    def _rate(self, quality):
        self.mgr._rate(quality)

    def _review_undo(self):
        self.mgr._review_undo()

    def _review_redo(self):
        self.mgr._review_redo()

    def _close_bg_prefetch_dialog(self):
        self._bg_accept_mode = False
        self._bg_prefetch_total_pages = 0
        self._bg_prefetch_cached_count = 0
        self._bg_prefetch_rendered_count = 0

    def _show_bg_prefetch_dialog(self, path: str, total_pages: int):
        pass

    def _sync_bg_prefetch_dialog(self, path: str, total_pages: int, done: bool = False):
        pass

    def _accept_bg_prefetch(self):
        self._bg_accept_mode = True
        self._flush_pending_background_inserts()

    def _rebuild_queue(self, peek_idx=None):
        self.mgr._rebuild_queue(peek_idx)

    def _sync_queue_state(self, peek_idx=None):
        self.mgr._sync_queue_state(peek_idx)

    def _check_learning_due(self):
        self.mgr._check_learning_due()

    def _promote_expired_learning(self, insert_pos):
        self.mgr._promote_expired_learning(insert_pos)

    def _trigger_center_fit(self):
        if self.__dict__.get("_peek_idx") is not None:
            self._exit_peek()
            return

        zoom_fit = self.__dict__.get("_zoom_fit")
        if zoom_fit is None:
            if "_canvas_scroll" not in self.__dict__ or "canvas" not in self.__dict__:
                return
            zoom_fit = self._zoom_fit

        center_on_target = self.__dict__.get("_center_on_target")
        if center_on_target is None:
            if "canvas" not in self.__dict__:
                return
            center_on_target = self._center_on_target

        zoom_fit()
        center_on_target()
        canvas = self.__dict__.get("canvas")
        if canvas is not None:
            self._user_zoom_scale = canvas._scale

    def _update_queue_label(self, total):
        dojo = _is_dojo()
        base = "▸  QUEUE" if dojo else "📋  Queue"
        self._queue_label.setText(f"{base} ({total})")

    def __init__(self, cards, data=None, parent=None):
        super().__init__(parent)
        from services.review_manager import ReviewSessionManager

        self.mgr = ReviewSessionManager(self)
        self._data = data
        self._cache_panel = None
        self._items = []
        self._pdf_cache = {}
        self._current_pixmap = None
        from services.pdf_watcher import PdfWatcher

        self._pdf_watcher = PdfWatcher(self)
        self._pdf_watcher.file_changed.connect(self._on_pdf_file_changed)
        self._pdf_watcher.reload_requested.connect(self._on_pdf_reload_requested)
        self._pdf_watcher.get_current_page_cb = lambda: self.canvas.get_current_page(
            self._canvas_scroll.verticalScrollBar().value()
        )
        self._pdf_watcher.get_hint_cb = lambda: (
            self._external_pdf_path_hint,
            self._external_pdf_page_hint,
        )
        self._watched_pdf_path = None
        self._review_ui_page_zero = 0
        self._review_nav_seq = 0
        self._pdf_render_zoom = 2.0

        self._pending_reload_page = None
        self._external_pdf_path_hint = None
        self._external_pdf_page_hint = None
        self._pending_visible_request = None
        self._pending_skeleton_result = None
        self._background_fill_state = None
        self._ondemand_kind = None
        self._ondemand_thread = None
        self._bg_pending_inserts = {}
        self._bg_accept_mode = False
        self._review_canvas_real_pages = set()
        self._review_render_inflight_pages = set()
        self._review_priority_pages_cache = {}
        self._review_adapted_boxes_cache = {}
        self._bg_prefetch_dialog = None
        self._bg_prefetch_total_pages = 0
        self._bg_prefetch_cached_count = 0
        self._bg_prefetch_rendered_count = 0
        self._queue_locked = self._load_queue_locked()
        self._queue_drawer_open = True
        self._queue_auto_hide_timer = QTimer(self)
        self._queue_auto_hide_timer.setSingleShot(True)
        self._queue_auto_hide_timer.setInterval(self.QUEUE_AUTO_HIDE_MS)
        self._queue_auto_hide_timer.timeout.connect(
            self._hide_queue_drawer_after_delay
        )
        self._floating_timer_sync_timer = None
        self._skeleton_thread = None
        self._ui_idle_timer = QTimer(self)
        self._ui_idle_timer.setSingleShot(True)
        self._ui_idle_timer.setInterval(220)
        self._ui_idle_timer.timeout.connect(self._on_ui_idle_timeout)
        self._peek_idx = None
        self._peek_origin_idx = None
        # ── User zoom tracking — None = no manual zoom set yet ────────────────
        self._user_zoom_scale = None
        self._review_ink_width = self._load_review_ink_width()
        # ── O(1) box tracking ─────────────────────────────────────────────────
        # All box_ids/group_ids that entered the queue (ever seen this session)
        self._queued_ids = set()
        # Tombstone set — deleted boxes, skip in _load_item
        self._deleted_ids = set()

        seen_item_keys = set()

        # ── SM-2 Debug Logger removed ─────────────────────────────────────────

        for card in cards:
            boxes = card.get("boxes", [])
            card_key = id(card)

            if len(boxes) == 0:
                item_key = (card_key, None)
                if item_key not in seen_item_keys:
                    seen_item_keys.add(item_key)
                    sm2_init(card)
                    self._items.append((card, None, card))
                continue

            seen_groups = set()

            for i, box in enumerate(boxes):
                sm2_init(box)
                gid = box.get("group_id", "")

                if gid:
                    if gid not in seen_groups:
                        seen_groups.add(gid)
                        item_key = (card_key, ("group", gid))
                        if item_key not in seen_item_keys:
                            seen_item_keys.add(item_key)
                            _due_result = is_due_today(box)
                            if _due_result:
                                self._items.append((card, ("group", gid), box))
                                self._queued_ids.add(gid)  # O(1) track
                else:
                    box_id = box.get("box_id", f"__idx_{i}")
                    item_key = (card_key, box_id)
                    if item_key not in seen_item_keys:
                        seen_item_keys.add(item_key)
                        _due_result = is_due_today(box)
                        if _due_result:
                            self._items.append((card, i, box))
                            self._queued_ids.add(box_id)  # O(1) track

        self._items.sort(key=lambda x: x[2].get("sm2_due", ""))
        self._idx = 0
        self._done = 0
        # ── Review undo/redo stacks ───────────────────────────────────────────
        # Each entry saves full state before a rating so Ctrl+Z can reverse it.
        # "Reset" = restore SM-2 fields to pre-rating values, not full history wipe.
        self._review_undo_stack = []  # list of state snapshots
        self._review_redo_stack = []  # cleared on new rating, filled on undo

        # ── Session Timer ─────────────────────────────────────────────────────
        if _TIMER_AVAILABLE:
            self._stimer = SessionTimer(self)
            self._stimer.start()
        else:
            self._stimer = None

        self._setup_ui()
        for w in (
            self,
            self.canvas,
            self._canvas_scroll.viewport(),
            self._queue_panel,
            self._queue_list.viewport(),
            self._queue_edge_button,
            self._queue_lock_button,
            self._queue_hide_button,
        ):
            try:
                w.setMouseTracking(True)
                w.installEventFilter(self)
            except Exception:
                pass
        self._load_item()

    def _toggle_cache_panel(self):
        from cache_manager import CacheManagerPanel

        if self._cache_panel is None:
            self._cache_panel = CacheManagerPanel(parent=self)
        if self._cache_panel.isVisible():
            self._cache_panel.hide()
        else:
            self._cache_panel.show()
            self._cache_panel.refresh()

    def closeEvent(self, e):
        from cache_manager import MASK_REGISTRY

        MASK_REGISTRY.unregister(self.canvas)
        self._close_bg_prefetch_dialog()
        self._stop_skeleton_thread()
        if (
            hasattr(self, "_pdf_loader_thread")
            and self._pdf_loader_thread
            and self._pdf_loader_thread.isRunning()
        ):
            self._pdf_loader_thread.stop()
            self._pdf_loader_thread.quit()
            self._pdf_loader_thread.wait(1000)

        # STEP 4 — stop on-demand thread on close
        self._stop_ondemand_thread()

        if hasattr(self, "_stop_watch"):
            self._pdf_watcher.stop_watch()

        # Stop timer and write focus time to today's journal
        if self._stimer:
            self._stimer.stop()
            self._stimer.flush_to_journal()

        super().closeEvent(e)

    def eventFilter(self, obj, event):
        et = event.type()
        if et in (
            QEvent.MouseMove,
            QEvent.HoverMove,
            QEvent.Wheel,
            QEvent.KeyPress,
            QEvent.MouseButtonPress,
            QEvent.MouseButtonRelease,
        ):
            self._note_user_activity()
        if et in (QEvent.MouseMove, QEvent.HoverMove):
            self._maybe_show_queue_edge_handle(event)
            self._update_queue_auto_hide_from_event(event)
        elif et in (QEvent.Enter, QEvent.Leave):
            self._update_queue_auto_hide_from_event(event)
        return super().eventFilter(obj, event)

    def _note_user_activity(self):
        self._ui_idle_timer.start()
        if self._stimer:
            self._stimer.note_activity()

    def _on_ui_idle_timeout(self):
        self._flush_pending_background_inserts()
        bg_state = self._background_fill_state
        if not bg_state:
            return
        if self._pending_visible_request:
            return
        if self._ondemand_thread and self._ondemand_thread.isRunning():
            return
        bg_path, bg_already_rendered, bg_total = bg_state
        if getattr(self, "_canvas_pdf_path", None) != bg_path:
            self._background_fill_state = None
            return
        self._start_background_fill(bg_path, bg_already_rendered, bg_total)

    def _on_pdf_reload_requested(self, path, current_page, target_page):
        key = os.path.abspath(path) if path else ""
        suppress_until = float(
            getattr(self, "_suppress_pdf_reload_until", {}).get(key, 0.0) or 0.0
        )
        if suppress_until and time.monotonic() <= suppress_until:
            return
        self._pending_reload_page = target_page
        self._reload_current_canvas()

    def _on_pdf_file_changed(self, path: str):
        if not path:
            return
        self.canvas._show_toast("PDF changed on disk — refreshing…")

    def _toggle_chrome(self):
        """Right-click on canvas — show/hide header and hint bars."""
        visible = self._hdr_widget.isVisible()
        self._hdr_widget.setVisible(not visible)
        self._hint_label.setVisible(not visible)

    def _show_overlay(self, overlay):
        """Show a floating overlay and reposition it."""
        self._reposition_overlays()
        overlay.show()
        overlay.raise_()

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._reposition_overlays()
        self._reposition_queue_edge_handle()
        self._reposition_queue_overlay()
        self._reposition_floating_timer()

    def _reposition_overlays(self):
        """Pin overlays to bottom-center of canvas scroll area."""
        ref = self._canvas_scroll
        w = ref.width()
        h = ref.height()

        # Rating frame — flush to bottom
        self._rating_frame.adjustSize()
        sh = self._rating_frame.sizeHint()
        rw = max(sh.width(), 10)
        rh = max(sh.height(), 48)
        self._rating_frame.setGeometry((w - rw) // 2, h - rh - 2, rw, rh)

        # Reveal bar — just above where rating would be
        self._reveal_bar.adjustSize()
        sh2 = self._reveal_bar.sizeHint()
        bw = max(sh2.width(), 10)
        bh = max(sh2.height(), 44)
        self._reveal_bar.setGeometry((w - bw) // 2, h - bh - 2, bw, bh)

    def _load_queue_locked(self) -> bool:
        raw = QSettings("AnkiOcclusion", "App").value("review/queue_locked", True)
        if isinstance(raw, bool):
            return raw
        return str(raw).strip().lower() not in {"0", "false", "no", "off"}

    def _save_queue_locked(self):
        settings = QSettings("AnkiOcclusion", "App")
        settings.setValue("review/queue_locked", bool(self._queue_locked))
        settings.sync()

    def _set_queue_locked(self, locked: bool):
        self._queue_locked = bool(locked)
        self._queue_drawer_open = True if self._queue_locked else False
        self._save_queue_locked()
        self._apply_queue_drawer_state()

    def _toggle_queue_lock(self):
        self._set_queue_locked(not bool(self.__dict__.get("_queue_locked", True)))

    def _open_queue_drawer(self):
        self._queue_drawer_open = True
        self._cancel_queue_auto_hide()
        self._apply_queue_drawer_state()

    def _toggle_queue_drawer(self):
        if self.__dict__.get("_queue_locked", True):
            return
        self._queue_drawer_open = not bool(
            self.__dict__.get("_queue_drawer_open", True)
        )
        self._cancel_queue_auto_hide()
        self._apply_queue_drawer_state()

    def _hide_queue_drawer(self):
        if self.__dict__.get("_queue_locked", True):
            return
        self._queue_drawer_open = False
        self._cancel_queue_auto_hide()
        self._apply_queue_drawer_state()

    def _apply_queue_drawer_state(self, recenter: bool = True):
        queue_panel = self.__dict__.get("_queue_panel")
        queue_list = self.__dict__.get("_queue_list")
        edge_button = self.__dict__.get("_queue_edge_button")
        lock_button = self.__dict__.get("_queue_lock_button")
        hide_button = self.__dict__.get("_queue_hide_button")
        if queue_panel is None:
            return

        locked = bool(self.__dict__.get("_queue_locked", True))
        open_now = locked or bool(self.__dict__.get("_queue_drawer_open", True))
        self._set_queue_panel_docked(locked)
        if not locked:
            queue_panel.hide()
        if queue_list is not None:
            queue_list.setVisible(open_now)

        if lock_button is not None:
            lock_button.setText("🔒" if locked else "🔓")
            lock_button.setToolTip(
                "Queue locked open" if locked else "Queue unlocked"
            )
        if hide_button is not None:
            hide_button.setVisible(not locked)
            hide_button.setText("›" if open_now else "‹")
            hide_button.setToolTip(
                "Hide queue items" if open_now else "Show queue items"
            )
        if edge_button is not None:
            edge_button.setVisible(False)

        self._reposition_queue_overlay()
        queue_panel.setVisible(open_now)
        self._update_floating_timer_visibility()

        if locked or not open_now:
            self._cancel_queue_auto_hide()

        if recenter:
            QTimer.singleShot(0, self._trigger_center_fit)

    def _set_queue_panel_docked(self, docked: bool):
        queue_panel = self.__dict__.get("_queue_panel")
        canvas_stage = self.__dict__.get("_canvas_stage")
        mid_layout = self.__dict__.get("_mid_layout")
        mid_widget = self.__dict__.get("_mid_widget")
        if (
            queue_panel is None
            or canvas_stage is None
            or mid_layout is None
            or mid_widget is None
        ):
            return

        if docked:
            if self.__dict__.get("_queue_panel_docked", True):
                queue_panel.setFixedWidth(200)
                queue_panel.setMinimumHeight(0)
                queue_panel.setMaximumHeight(16777215)
                return
            queue_panel.hide()
            queue_panel.setParent(mid_widget)
            mid_layout.addWidget(queue_panel)
            self._queue_panel_docked = True
            queue_panel.setFixedWidth(200)
            queue_panel.setMinimumHeight(0)
            queue_panel.setMaximumHeight(16777215)
            queue_panel.show()
            return

        if not self.__dict__.get("_queue_panel_docked", True):
            return
        queue_panel.hide()
        mid_layout.removeWidget(queue_panel)
        queue_panel.setParent(canvas_stage)
        self._queue_panel_docked = False
        queue_panel.setFixedWidth(200)

    def _reposition_queue_overlay(self):
        queue_panel = self.__dict__.get("_queue_panel")
        canvas_stage = self.__dict__.get("_canvas_stage")
        if (
            queue_panel is None
            or canvas_stage is None
            or self.__dict__.get("_queue_panel_docked", True)
        ):
            return

        width = 200
        locked = bool(self.__dict__.get("_queue_locked", True))
        open_now = locked or bool(self.__dict__.get("_queue_drawer_open", True))
        queue_panel.setFixedWidth(width)
        if open_now:
            queue_panel.setMinimumHeight(0)
            queue_panel.setMaximumHeight(16777215)
            queue_panel.setFixedHeight(max(1, canvas_stage.height()))
        else:
            queue_panel.adjustSize()
            compact_height = min(
                max(queue_panel.sizeHint().height(), queue_panel.minimumSizeHint().height()),
                max(1, canvas_stage.height()),
            )
            queue_panel.setFixedHeight(compact_height)

        queue_panel.move(max(0, canvas_stage.width() - width - 8), 0)
        queue_panel.raise_()

    def _sync_floating_timer(self):
        if not self.__dict__.get("_stimer"):
            return
        session_label = self.__dict__.get("_floating_timer_session")
        today_label = self.__dict__.get("_floating_timer_today")
        if session_label is not None:
            session_label.setText(self._stimer.label_session.text())
        if today_label is not None:
            today_label.setText(self._stimer.label_today.text())
        self._reposition_floating_timer()

    def _keep_floating_timer_on_top(self):
        frame = self.__dict__.get("_floating_timer_frame")
        if frame is None or frame.isHidden():
            return
        self._reposition_floating_timer()
        QTimer.singleShot(0, self._reposition_floating_timer)

    def _reposition_floating_timer(self):
        frame = self.__dict__.get("_floating_timer_frame")
        canvas_stage = self.__dict__.get("_canvas_stage")
        if frame is None or canvas_stage is None:
            return
        frame.adjustSize()
        margin = 10
        frame.move(
            max(margin, canvas_stage.width() - frame.width() - margin),
            margin,
        )
        frame.raise_()

    def _update_floating_timer_visibility(self):
        frame = self.__dict__.get("_floating_timer_frame")
        if frame is None:
            return
        locked = bool(self.__dict__.get("_queue_locked", True))
        open_now = locked or bool(self.__dict__.get("_queue_drawer_open", True))
        show_float = bool(self.__dict__.get("_stimer")) and not open_now
        if show_float:
            self._sync_floating_timer()
            if not self.__dict__.get("_floating_timer_visible", False):
                print("[DEBUG][review_timer] floating_timer visible=yes")
            self._floating_timer_visible = True
            frame.show()
            frame.raise_()
        else:
            if self.__dict__.get("_floating_timer_visible", False):
                print("[DEBUG][review_timer] floating_timer visible=no")
            self._floating_timer_visible = False
            frame.hide()

    def _reposition_queue_edge_handle(self):
        edge_button = self.__dict__.get("_queue_edge_button")
        if edge_button is None:
            return
        width = max(edge_button.sizeHint().width(), 28)
        height = max(edge_button.sizeHint().height(), 58)
        edge_button.setFixedSize(width, height)
        edge_button.move(
            max(0, self.width() - width - 2),
            max(0, (self.height() - height) // 2),
        )

    def _maybe_show_queue_edge_handle(self, event):
        queue_panel = self.__dict__.get("_queue_panel")
        if queue_panel is not None and queue_panel.isVisible():
            return
        if self.__dict__.get("_queue_locked", True):
            return
        if self.__dict__.get("_queue_drawer_open", True):
            return
        edge_button = self.__dict__.get("_queue_edge_button")
        if edge_button is None:
            return
        pos = event.pos()
        try:
            if event.globalPos is not None:
                pos = self.mapFromGlobal(event.globalPos())
        except Exception:
            pass
        if pos.x() >= self.width() - 10:
            self._reposition_queue_edge_handle()
            edge_button.show()
            edge_button.raise_()

    def _event_global_pos(self, event):
        try:
            return event.globalPos()
        except Exception:
            return QCursor.pos()

    def _queue_contains_global_pos(self, global_pos) -> bool:
        queue_panel = self.__dict__.get("_queue_panel")
        if queue_panel is None or not queue_panel.isVisible():
            return False
        return queue_panel.rect().contains(queue_panel.mapFromGlobal(global_pos))

    def _cancel_queue_auto_hide(self):
        timer = self.__dict__.get("_queue_auto_hide_timer")
        if timer is not None:
            timer.stop()

    def _schedule_queue_auto_hide(self):
        timer = self.__dict__.get("_queue_auto_hide_timer")
        if timer is not None:
            if not timer.isActive():
                timer.start(self.QUEUE_AUTO_HIDE_MS)

    def _update_queue_auto_hide_from_event(self, event):
        if self.__dict__.get("_queue_locked", True):
            self._cancel_queue_auto_hide()
            return
        if not self.__dict__.get("_queue_drawer_open", True):
            self._cancel_queue_auto_hide()
            return
        queue_panel = self.__dict__.get("_queue_panel")
        if queue_panel is None or not queue_panel.isVisible():
            self._cancel_queue_auto_hide()
            return
        if self._queue_contains_global_pos(self._event_global_pos(event)):
            self._cancel_queue_auto_hide()
        else:
            self._schedule_queue_auto_hide()

    def _hide_queue_drawer_after_delay(self):
        if self.__dict__.get("_queue_locked", True):
            return
        if not self.__dict__.get("_queue_drawer_open", True):
            return
        if self._queue_contains_global_pos(QCursor.pos()):
            self._cancel_queue_auto_hide()
            return
        self._hide_queue_drawer()

    def _load_item(self):
        # [O(1) FIX] Skip tombstoned (deleted) boxes
        while self._idx < len(self._items):
            _, b, _ = self._items[self._idx]
            bid = b[1] if isinstance(b, tuple) else (b if isinstance(b, str) else "")
            if bid and bid in self._deleted_ids:
                self._idx += 1
            else:
                break

        if self._idx >= len(self._items):
            self._finish()
            return

        card, box_idx, sm2_obj = self._items[self._idx]
        if hasattr(self.canvas, "clear_review_ink_for_card_switch"):
            self.canvas.clear_review_ink_for_card_switch()
        self._sync_queue_state()  # state-only fast path for normal card advances

        # UI updates...
        self.prog.setMaximum(len(self._items))
        self.prog.setValue(self._idx)
        self.lbl_prog.setText(f"Card {self._idx + 1}/{len(self._items)}")
        self.lbl_sm2.setText(sm2_badge(sm2_obj))
        self.lbl_title.setText(card.get("title", "Untitled"))

        # 🚀 SM-2 SIMULATION UPDATE
        previews = _fmt_due_interval(sm2_obj)
        for (btn, q), (orig_lbl, _, _), color_lbl in zip(
            self._prev_lbls, self.RATINGS, self.RATING_LABELS
        ):
            val = previews.get(q, "?")
            # orig_lbl e.g. "1  🔁 Again" → parts[0]="1", parts[1]="🔁"
            parts = orig_lbl.split()
            icon = parts[1] if len(parts) > 1 else ""
            btn.setText(f"{parts[0]} {icon}  {val}  {color_lbl}")

        current_path = getattr(self.canvas, "_current_pdf_path", "") or getattr(
            self, "_canvas_pdf_path", ""
        )
        new_path = resolve_asset_path(card.get("pdf_path", ""))
        same_pdf = bool(
            current_path
            and new_path
            and os.path.abspath(current_path) == os.path.abspath(new_path)
        )

        if same_pdf and getattr(self.canvas, "_pages", None):
            self._canvas_pdf_path = new_path
            self.canvas._current_pdf_path = new_path
            if hasattr(self.canvas, "clear_peek_target"):
                self.canvas.clear_peek_target()
            boxes = card.get("boxes", [])
            if new_path and boxes:
                source_box_zoom = card.get("_pdf_box_render_zoom", PDF_LEGACY_BOX_ZOOM)
                boxes = self._adapt_review_boxes(card, new_path)
                self._pdf_quality_debug(
                    "same_pdf_box_remap",
                    source_zoom=source_box_zoom,
                    target_zoom=self._pdf_render_zoom,
                    boxes=len(boxes),
                    review_idx=self._idx,
                )
            if isinstance(box_idx, tuple) and box_idx[0] == "group":
                gid = box_idx[1]
                display_boxes = [{**b, "revealed": False} for b in boxes]
                self.canvas.set_boxes_with_state(display_boxes)
                self.canvas.set_target_box(-1)
                self.canvas.set_mode("review")
                self.canvas.set_target_group(gid)
            elif box_idx is None:
                self.canvas.set_boxes_with_state(
                    [{**b, "revealed": False} for b in boxes]
                )
                self.canvas.set_target_box(-1)
                self.canvas.set_mode("review")
            else:
                display_boxes = [{**b, "revealed": False} for b in boxes]
                self.canvas.set_boxes_with_state(display_boxes)
                self.canvas.set_target_box(box_idx if isinstance(box_idx, int) else -1)
                self.canvas.set_mode("review")

            # FIX: retain user-set zoom on same-PDF card switch too
            def _same_pdf_zoom_center():
                if self._user_zoom_scale is not None:
                    self.canvas._scale = self._user_zoom_scale
                    self.canvas._on_zoom()
                self._center_on_target()
                self._update_review_page_nav_ui()

            QTimer.singleShot(0, _same_pdf_zoom_center)
        else:
            self._reload_current_canvas()

        self.canvas.setFocus()  # यह पक्का करेगा कि Keyboard Commands सीधे Canvas पकड़ें
        self._rating_frame.hide()  # ← rating frame explicitly hide karo
        QTimer.singleShot(50, lambda: self._show_overlay(self._reveal_bar))

    def keyPressEvent(self, e):
        key = e.key()
        mods = e.modifiers()
        if (
            getattr(self, "canvas", None) is not None
            and getattr(self.canvas, "_mode", "") == "edit"
        ):
            if mods & Qt.ControlModifier and key == Qt.Key_A:
                if mods & Qt.AltModifier:
                    self.canvas.select_all_on_pdf()
                elif mods & Qt.ShiftModifier:
                    self.canvas.select_all_in_view()
                else:
                    self.canvas.select_visible_only()
                self.canvas.setFocus()
                e.accept()
                return
        if shortcut_manager.event_matches(e, "review.fullscreen"):
            win = self.window()
            if win.isFullScreen():
                win.showMaximized()
                self._set_fullscreen_ui(False)
            else:
                win.showFullScreen()
                self._set_fullscreen_ui(True)
        elif shortcut_manager.event_matches(e, "review.cancel"):
            self.cancelled.emit()
        elif shortcut_manager.event_matches(e, "review.reveal"):
            if self._rating_frame.isVisible():
                # Already revealed — hide karo (toggle back)
                self._rating_frame.hide()
                self._show_overlay(self._reveal_bar)
                # Masks wapas hide karo
                for b in self.canvas._boxes:
                    b["revealed"] = False
                self.canvas._redraw()
            else:
                self._reveal_current()
        elif self._rating_frame.isVisible() and self._rating_quality_for_event(e) is not None:
            self._rate(self._rating_quality_for_event(e))
        elif shortcut_manager.event_matches(e, "review.zoom_in"):
            self.canvas.zoom_in()
            self._user_zoom_scale = self.canvas._scale
        elif shortcut_manager.event_matches(e, "review.zoom_out"):
            self.canvas.zoom_out()
            self._user_zoom_scale = self.canvas._scale
        elif shortcut_manager.event_matches(e, "review.zoom_reset"):
            self._zoom_fit()
            self._user_zoom_scale = None  # reset to auto-fit
        elif shortcut_manager.event_matches(e, "review.center"):
            self._trigger_center_fit()
        elif key == Qt.Key_D and not e.isAutoRepeat():
            self._debug_report("D key (manual)")
        elif shortcut_manager.event_matches(e, "review.undo"):
            self._review_undo()
        elif shortcut_manager.event_matches(e, "review.redo"):
            self._review_redo()
        elif shortcut_manager.event_matches(e, "review.open_pdf"):
            self._open_current_pdf_in_reader()
        elif shortcut_manager.event_matches(e, "review.open_folder"):
            self._reveal_current_pdf_in_folder()
        elif shortcut_manager.event_matches(e, "review.copy_pdf") and not e.isAutoRepeat():
            self._copy_current_pdf_file_to_clipboard()
        elif shortcut_manager.event_matches(e, "review.annotate") and not e.isAutoRepeat():
            self._open_annotation_beta()
        elif shortcut_manager.event_matches(e, "review.edit_card"):
            self._edit_current_card()
        elif shortcut_manager.event_matches(e, "review.prev_page") and not e.isAutoRepeat():
            self._go_prev_review_page()
        elif shortcut_manager.event_matches(e, "review.next_page") and not e.isAutoRepeat():
            self._go_next_review_page()
        elif (
            key == Qt.Key_Alt
            or shortcut_manager.event_matches(e, "review.pen_toggle")
        ) and not e.isAutoRepeat():
            self.canvas.ink_toggle()
            active = self.canvas._ink_active
            color = self.canvas._ink_colors[self.canvas._ink_color_idx]
            self.canvas._show_toast(
                f"✏ Pen {'ON' if active else 'OFF'}  {color if active else ''}"
            )
            self._update_ink_hint()
        elif (
            key in (Qt.Key_Equal, Qt.Key_Plus)
            and not (mods & Qt.ControlModifier)
            and getattr(self.canvas, "_ink_active", False)
        ):
            self.canvas.ink_adjust_width(0.4)
            self._capture_review_ink_width("width_plus")
        elif (
            key == Qt.Key_Minus
            and not (mods & Qt.ControlModifier)
            and getattr(self.canvas, "_ink_active", False)
        ):
            self.canvas.ink_adjust_width(-0.4)
            self._capture_review_ink_width("width_minus")
        elif shortcut_manager.event_matches(e, "review.pen_color") and not e.isAutoRepeat():
            if self.canvas._ink_active:
                self.canvas.ink_cycle_color()
        elif shortcut_manager.event_matches(e, "review.pen_clear") and not e.isAutoRepeat():
            self.canvas.ink_clear()
        else:
            super().keyPressEvent(e)

    def _rating_quality_for_event(self, event):
        for action_id, quality in self.RATING_SHORTCUT_ACTIONS:
            if shortcut_manager.event_matches(event, action_id):
                return quality
        return None

    def _reveal_current(self):
        if not (0 <= self._idx < len(self._items)):
            return
        _, box_idx, _ = self._items[self._idx]
        if box_idx is None:
            self.canvas.reveal_all()
        elif isinstance(box_idx, tuple) and box_idx[0] == "group":
            gid = box_idx[1]
            for b in self.canvas._boxes:
                if b.get("group_id", "") == gid:
                    b["revealed"] = True
            self.canvas._redraw()
        else:
            if 0 <= box_idx < len(self.canvas._boxes):
                self.canvas._boxes[box_idx]["revealed"] = True
                self.canvas._redraw()
        self._reveal_bar.hide()
        self._show_overlay(self._rating_frame)

    def _exit_peek(self):
        if self._peek_idx is None:
            return
        self._peek_idx = None
        self._peek_origin_idx = None
        if hasattr(self.canvas, "set_peek_active"):
            self.canvas.set_peek_active(False)
        if hasattr(self.canvas, "clear_peek_target"):
            self.canvas.clear_peek_target()
        self._rebuild_queue()
        self._center_on_target()

    def _jump_to_queue_index(self, idx, from_peek=False):
        if not (0 <= idx < len(self._items)):
            return
        if self._peek_origin_idx is None:
            self._peek_origin_idx = self._idx
        self._peek_idx = idx
        card, box_idx, _ = self._items[idx]
        if hasattr(self.canvas, "set_peek_target_box"):
            if isinstance(box_idx, tuple) and box_idx[0] == "group":
                self.canvas.set_peek_target_group(box_idx[1])
            else:
                self.canvas.set_peek_target_box(
                    box_idx if isinstance(box_idx, int) else -1
                )
        if hasattr(self.canvas, "set_peek_active"):
            self.canvas.set_peek_active(True)
        self._rebuild_queue(peek_idx=idx)
        self._center_on_target()

    def _on_queue_item_clicked(self, item):
        idx = item.data(QUEUE_INDEX_ROLE)
        if idx is None:
            return
        self._jump_to_queue_index(int(idx))

    def _set_fullscreen_ui(self, fullscreen: bool):
        self._hdr_widget.setVisible(not fullscreen)
        self.lbl_title.setVisible(False)  # always hidden
        self._hint_label.setVisible(not fullscreen)

    def _setup_ui(self):
        dojo = _is_dojo()
        from theme_manager import get_palette

        app = QApplication.instance()
        theme = getattr(app, "_active_theme", "classic")
        p = get_palette(theme)

        # ── resolved palette ──────────────────────────────────────────────────
        bg = p.get("C_BG", C_BG)
        surface = p.get("C_SURFACE", C_SURFACE)
        card = p.get("C_CARD", C_CARD)
        accent = p.get("C_ACCENT", C_ACCENT)
        accent2 = p.get("C_PURPLE", C_ACCENT)
        text = p.get("C_TEXT", C_TEXT)
        subtext = p.get("C_SUBTEXT", C_SUBTEXT)
        border = p.get("C_BORDER", C_BORDER)
        font = p.get("header_font", "'Segoe UI'").split(",")[0].strip("'")

        L = QVBoxLayout(self)
        L.setContentsMargins(0, 0, 0, 0)
        L.setSpacing(0)

        # ── Header bar ────────────────────────────────────────────────────────
        hdr_w = QFrame()
        hdr_w.setFixedHeight(52 if dojo else 46)
        if dojo:
            hdr_w.setStyleSheet(
                f"QFrame{{background:{surface};"
                f"border-bottom:2px solid {accent};border-radius:0;}}"
            )
        else:
            hdr_w.setStyleSheet(
                f"QFrame{{background:{surface};"
                f"border-bottom:1px solid {border};border-radius:0;}}"
            )
        hdr = QHBoxLayout(hdr_w)
        hdr.setContentsMargins(14, 0, 14, 0)
        hdr.setSpacing(10)

        self.lbl_prog = QLabel("Card 1/1")
        if dojo:
            self.lbl_prog.setFont(QFont(font, 9, QFont.Bold))
            self.lbl_prog.setStyleSheet(
                f"color:{accent};letter-spacing:2px;font-family:{font};"
            )
        else:
            self.lbl_prog.setFont(QFont("Segoe UI", 12, QFont.Bold))
        hdr.addWidget(self.lbl_prog)

        self.prog = QProgressBar()
        self.prog.setFixedHeight(6 if dojo else 8)
        self.prog.setTextVisible(False)
        if dojo:
            self.prog.setStyleSheet(
                f"QProgressBar{{background:{card};border-radius:3px;"
                f"border:1px solid {border};}}"
                f"QProgressBar::chunk{{background:{accent};border-radius:3px;}}"
            )
        else:
            self.prog.setStyleSheet(
                f"QProgressBar{{background:{card};border-radius:4px;}}"
                f"QProgressBar::chunk{{background:{accent};border-radius:4px;}}"
            )
        hdr.addWidget(self.prog, stretch=1)

        self.lbl_sm2 = QLabel("")
        if dojo:
            self.lbl_sm2.setStyleSheet(
                f"background:{card};color:{accent2};"
                f"border:1px solid {accent2};border-radius:2px;"
                f"padding:2px 8px;font-size:9px;font-family:{font};"
                f"letter-spacing:1px;"
            )
        else:
            self.lbl_sm2.setStyleSheet(
                f"background:{card};color:{subtext};"
                f"border-radius:6px;padding:3px 10px;font-size:11px;"
            )
        hdr.addWidget(self.lbl_sm2)

        def _zb(txt, tip):
            b = QPushButton(txt)
            b.setToolTip(tip)
            b.setFixedSize(28, 28)
            if dojo:
                b.setStyleSheet(
                    f"QPushButton{{background:{card};color:{accent};"
                    f"border:1px solid {border};border-radius:2px;font-size:13px;}}"
                    f"QPushButton:hover{{background:rgba(114,255,79,0.12);"
                    f"border:1px solid {accent};}}"
                )
            else:
                b.setStyleSheet(
                    f"QPushButton{{background:{card};color:{text};"
                    f"border:1px solid {border};border-radius:5px;font-size:13px;}}"
                    f"QPushButton:hover{{background:{surface};}}"
                )
            return b

        b_zin = _zb("+", "Zoom In  Ctrl++")
        b_zout = _zb("−", "Zoom Out  Ctrl+−")
        b_zfit = _zb("⊡", "Zoom Fit  Ctrl+0")
        b_center = _zb("⊕", "Center on active mask")
        self._btn_prev_page = _zb("←", "Previous PDF page")
        self._btn_next_page = _zb("→", "Next PDF page")
        self._btn_prev_page.setFocusPolicy(Qt.NoFocus)
        self._btn_next_page.setFocusPolicy(Qt.NoFocus)
        self._page_jump = QLineEdit()
        self._page_jump.setFixedWidth(46)
        self._page_jump.setAlignment(Qt.AlignCenter)
        self._page_jump.returnPressed.connect(self._jump_to_review_page_from_input)
        self._page_total = QLabel("/ 0")
        self._page_total.setStyleSheet(f"color:{subtext};background:transparent;")
        def _manual_zoom(direction: int):
            if direction > 0:
                self.canvas.zoom_in()
            else:
                self.canvas.zoom_out()
            self._user_zoom_scale = self.canvas._scale

        b_zin.clicked.connect(lambda: _manual_zoom(+1))
        b_zout.clicked.connect(lambda: _manual_zoom(-1))
        b_zfit.clicked.connect(self._zoom_fit)
        b_center.clicked.connect(self._center_on_target)
        self._btn_prev_page.clicked.connect(self._go_prev_review_page)
        self._btn_next_page.clicked.connect(self._go_next_review_page)
        hdr.addWidget(b_zin)
        hdr.addWidget(b_zout)
        hdr.addWidget(b_zfit)
        hdr.addWidget(b_center)
        hdr.addWidget(self._btn_prev_page)
        hdr.addWidget(self._btn_next_page)
        hdr.addWidget(self._page_jump)
        hdr.addWidget(self._page_total)

        def _hdr_btn(label, primary=False):
            b = QPushButton(label)
            if dojo:
                if primary:
                    b.setStyleSheet(
                        f"QPushButton{{background:{accent};color:{bg};"
                        f"border:none;border-radius:2px;padding:4px 14px;"
                        f"font-size:7.5px;font-weight:900;font-family:{font};"
                        f"letter-spacing:0.5px;}}"
                        f"QPushButton:hover{{background:white;color:{bg};}}"
                    )
                else:
                    b.setStyleSheet(
                        f"QPushButton{{background:{card};color:{text};"
                        f"border:1px solid {border};border-radius:2px;"
                        f"padding:4px 14px;font-size:7.5px;"
                        f"font-family:{font};letter-spacing:0.5px;}}"
                        f"QPushButton:hover{{background:rgba(114,255,79,0.08);"
                        f"border:1px solid {accent};}}"
                    )
            else:
                if primary:
                    b.setStyleSheet(
                        f"QPushButton{{background:{accent};color:white;border:none;"
                        f"border-radius:6px;padding:4px 14px;"
                        f"font-size:12px;font-weight:bold;}}"
                        f"QPushButton:hover{{background:#6A58E0;}}"
                    )
                else:
                    b.setStyleSheet(
                        f"QPushButton{{background:{card};color:{text};"
                        f"border:1px solid {border};border-radius:6px;"
                        f"padding:4px 14px;font-size:12px;}}"
                        f"QPushButton:hover{{background:{surface};}}"
                    )
            return b

        b_edit = _hdr_btn("✏ Edit Card", primary=True)
        b_edit.clicked.connect(self._edit_current_card)
        b_annot = _hdr_btn("🖊 Anotate Scroll")
        b_annot.clicked.connect(self._open_annotation_beta)
        b_cache = _hdr_btn("💾 Cache")
        b_cache.clicked.connect(self._toggle_cache_panel)
        hdr.addWidget(b_edit)
        hdr.addWidget(b_annot)
        hdr.addWidget(b_cache)

        self._btn_mode = _hdr_btn("🟧 Hide All, Guess One")
        self._btn_mode.setCheckable(True)
        self._btn_mode.setChecked(False)
        if dojo:
            self._btn_mode.setStyleSheet(
                self._btn_mode.styleSheet()
                + f"QPushButton:checked{{background:{accent2};color:white;"
                f"border:1px solid {accent2};}}"
            )
        else:
            self._btn_mode.setStyleSheet(
                f"QPushButton{{background:{card};color:{text};"
                f"border:1px solid {border};border-radius:6px;"
                f"padding:4px 14px;font-size:12px;}}"
                f"QPushButton:checked{{background:#6A3FBF;color:white;"
                f"border:1px solid {accent};}}"
                f"QPushButton:hover{{background:{surface};}}"
            )
        self._btn_mode.clicked.connect(self._toggle_review_mode)
        hdr.addWidget(self._btn_mode)

        b_exit = _hdr_btn("✕ Exit")
        b_exit.clicked.connect(self.cancelled.emit)
        hdr.addWidget(b_exit)

        L.addWidget(hdr_w)
        self._hdr_widget = hdr_w
        self._hdr_widget.hide()

        self.lbl_title = QLabel("")
        self.lbl_title.setFont(
            QFont(font if dojo else "Segoe UI", 10 if dojo else 12, QFont.Bold)
        )
        if dojo:
            self.lbl_title.setStyleSheet(
                f"color:{accent};background:{bg};"
                f"padding:4px 16px;border-bottom:2px solid {accent};"
                f"letter-spacing:3px;font-family:{font};"
            )
        else:
            self.lbl_title.setStyleSheet(
                f"color:{accent};background:{bg};"
                f"padding:4px 16px;border-bottom:1px solid {border};"
            )
        self.lbl_title.setFixedHeight(30)
        self.lbl_title.hide()
        L.addWidget(self.lbl_title)

        # ── Canvas scroll area ────────────────────────────────────────────────
        self._canvas_scroll = _ZoomableScrollArea()
        self._canvas_scroll.setWidgetResizable(False)
        self._canvas_scroll.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        self._canvas_scroll.setStyleSheet(
            f"QScrollArea{{border:none;background:{bg};}}"
            f"QScrollBar:vertical{{background:{surface};width:8px;border-radius:4px;}}"
            f"QScrollBar::handle:vertical{{background:{border};border-radius:4px;}}"
            f"QScrollBar:horizontal{{background:{surface};height:8px;border-radius:4px;}}"
            f"QScrollBar::handle:horizontal{{background:{border};border-radius:4px;}}"
        )
        self.canvas = OcclusionCanvas()
        self.canvas.set_mode("review")
        self.canvas._ink_width = float(self._review_ink_width)
        self._activate_default_review_pen()
        self.canvas.right_clicked.connect(self._toggle_chrome)
        self._canvas_scroll.setWidget(self.canvas)
        self._canvas_scroll.set_canvas(self.canvas)
        self.canvas._zoom_timer.timeout.connect(self._on_canvas_zoom_settled)
        self._canvas_scroll.horizontalScrollBar().valueChanged.connect(
            lambda *_: self._note_user_activity()
        )
        self._canvas_scroll.horizontalScrollBar().valueChanged.connect(
            lambda *_: self._keep_floating_timer_on_top()
        )
        self._canvas_scroll.verticalScrollBar().valueChanged.connect(
            lambda *_: self._note_user_activity()
        )
        self._canvas_scroll.verticalScrollBar().valueChanged.connect(
            lambda *_: self._keep_floating_timer_on_top()
        )
        self._canvas_scroll.verticalScrollBar().valueChanged.connect(
            self._on_review_scroll_page_changed
        )

        self._sc_prev_page = QShortcut(
            QKeySequence(shortcut_manager.shortcut_text("review.prev_page")), self
        )
        self._sc_prev_page.setContext(Qt.WidgetWithChildrenShortcut)
        self._sc_prev_page.setAutoRepeat(False)
        self._sc_prev_page.activated.connect(self._go_prev_review_page)

        self._sc_next_page = QShortcut(
            QKeySequence(shortcut_manager.shortcut_text("review.next_page")), self
        )
        self._sc_next_page.setContext(Qt.WidgetWithChildrenShortcut)
        self._sc_next_page.setAutoRepeat(False)
        self._sc_next_page.activated.connect(self._go_next_review_page)

        self._pdf_viewer = PdfViewerController(
            canvas=self.canvas,
            scroll_area=self._canvas_scroll,
            page_input=self._page_jump,
            page_total_label=self._page_total,
            prev_button=self._btn_prev_page,
            next_button=self._btn_next_page,
            total_pages_getter=lambda: len(getattr(self.canvas, "_pages", []) or []),
            debug_hook=self._review_nav_debug,
        )

        self._canvas_stage = QWidget()
        self._canvas_stage.setStyleSheet(f"background:{bg};")
        canvas_stage_l = QVBoxLayout(self._canvas_stage)
        canvas_stage_l.setContentsMargins(0, 0, 0, 0)
        canvas_stage_l.setSpacing(0)
        canvas_stage_l.addWidget(self._canvas_scroll)

        self._floating_timer_frame = None
        self._floating_timer_session = None
        self._floating_timer_today = None
        if self._stimer:
            floating_timer = QFrame(self._canvas_stage)
            floating_timer.setToolTip("Study timer")
            floating_timer.setAttribute(Qt.WA_TransparentForMouseEvents, True)
            if dojo:
                floating_timer.setStyleSheet(
                    f"QFrame{{background:rgba(7,7,11,215);"
                    f"border:1px solid {border};border-radius:2px;}}"
                )
            else:
                floating_timer.setStyleSheet(
                    f"QFrame{{background:rgba(30,30,46,220);"
                    f"border:1px solid {border};border-radius:6px;}}"
                )
            ft_l = QVBoxLayout(floating_timer)
            ft_l.setContentsMargins(8, 5, 8, 5)
            ft_l.setSpacing(0)
            self._floating_timer_session = QLabel(self._stimer.label_session.text())
            self._floating_timer_today = QLabel(self._stimer.label_today.text())
            if dojo:
                self._floating_timer_session.setStyleSheet(
                    f"color:{accent};background:transparent;border:none;"
                    f"font-size:{self.FLOATING_TIMER_SESSION_FONT_PX}px;"
                    f"font-weight:bold;font-family:{font};"
                )
                self._floating_timer_today.setStyleSheet(
                    f"color:{accent2};background:transparent;border:none;"
                    f"font-size:{self.FLOATING_TIMER_TODAY_FONT_PX}px;"
                    f"font-weight:bold;font-family:{font};"
                )
            else:
                self._floating_timer_session.setStyleSheet(
                    "color:#CDD6F4;background:transparent;border:none;"
                    f"font-size:{self.FLOATING_TIMER_SESSION_FONT_PX}px;"
                    "font-weight:bold;"
                    "font-family:'Segoe UI Mono','Courier New',monospace;"
                )
                self._floating_timer_today.setStyleSheet(
                    f"color:{subtext};background:transparent;border:none;"
                    f"font-size:{self.FLOATING_TIMER_TODAY_FONT_PX}px;"
                    "font-weight:bold;"
                    "font-family:'Segoe UI Mono','Courier New',monospace;"
                )
            ft_l.addWidget(self._floating_timer_session)
            ft_l.addWidget(self._floating_timer_today)
            floating_timer.hide()
            self._floating_timer_frame = floating_timer
            self._floating_timer_sync_timer = QTimer(self)
            self._floating_timer_sync_timer.setInterval(1000)
            self._floating_timer_sync_timer.timeout.connect(self._sync_floating_timer)
            self._floating_timer_sync_timer.start()

        # ── Queue panel (right sidebar) ───────────────────────────────────────
        queue_panel = QWidget()
        queue_panel.setFixedWidth(200)
        if dojo:
            queue_panel.setStyleSheet(
                f"background:{surface};border-left:1px solid {border};"
            )
        else:
            queue_panel.setStyleSheet(f"background:{surface};")
        qp_l = QVBoxLayout(queue_panel)
        qp_l.setContentsMargins(6, 8, 6, 8)
        qp_l.setSpacing(4)

        if self._stimer:
            timer_frame = QFrame()
            if dojo:
                timer_frame.setStyleSheet(
                    f"QFrame{{background:{card};border-radius:2px;"
                    f"border:1px solid {border};}}"
                )
            else:
                timer_frame.setStyleSheet(
                    f"QFrame{{background:{card};border-radius:8px;"
                    f"border:1px solid {border};}}"
                )
            tf_l = QVBoxLayout(timer_frame)
            tf_l.setContentsMargins(8, 6, 8, 6)
            tf_l.setSpacing(2)

            tf_top = QLabel("⏱  CURRENT SESSION" if dojo else "⏱  Current session")
            tf_bot = QLabel("📅  TODAY'S FOCUS" if dojo else "📅  Today's focus")
            if dojo:
                tf_top.setStyleSheet(
                    f"color:{subtext};font-size:7px;font-weight:bold;"
                    f"background:transparent;border:none;"
                    f"font-family:{font};letter-spacing:1.5px;"
                )
                tf_bot.setStyleSheet(
                    f"color:{subtext};font-size:7px;font-weight:bold;"
                    f"background:transparent;border:none;"
                    f"font-family:{font};letter-spacing:1.5px;margin-top:6px;"
                )

                self._stimer.label_session.setStyleSheet(
                    f"background:transparent;color:{accent};"
                    f"font-size:18px;font-weight:bold;"
                    f"font-family:{font};border:none;"
                )
                self._stimer.label_today.setStyleSheet(
                    f"background:transparent;color:{accent2};"
                    f"font-size:14px;font-weight:bold;"
                    f"font-family:{font};border:none;"
                )
            else:
                tf_top.setStyleSheet(
                    f"color:{subtext};font-size:10px;"
                    f"font-weight:bold;background:transparent;border:none;"
                )
                tf_bot.setStyleSheet(
                    f"color:{subtext};font-size:10px;"
                    f"font-weight:bold;background:transparent;border:none;margin-top:6px;"
                )

                self._stimer.label_session.setStyleSheet(
                    f"background:transparent;color:#CDD6F4;"
                    f"font-size:18px;font-weight:bold;"
                    f"font-family:'Segoe UI Mono','Courier New',monospace;"
                    f"border:none;"
                )
                self._stimer.label_today.setStyleSheet(
                    f"background:transparent;color:{subtext};"
                    f"font-size:14px;font-weight:bold;"
                    f"font-family:'Segoe UI Mono','Courier New',monospace;"
                    f"border:none;"
                )

            tf_l.addWidget(tf_top)
            tf_l.addWidget(self._stimer.label_session)
            tf_l.addWidget(tf_bot)
            tf_l.addWidget(self._stimer.label_today)
            qp_l.addWidget(timer_frame)
            qp_l.addSpacing(6)

        queue_header = QWidget()
        queue_header_l = QHBoxLayout(queue_header)
        queue_header_l.setContentsMargins(0, 0, 0, 0)
        queue_header_l.setSpacing(4)

        self._queue_label = QLabel("▸  QUEUE" if dojo else "📋  Queue")
        if dojo:
            self._queue_label.setStyleSheet(
                f"color:{accent};font-size:8px;font-weight:bold;"
                f"font-family:{font};letter-spacing:2px;"
                f"padding-bottom:4px;"
            )
        else:
            self._queue_label.setStyleSheet(
                f"color:{subtext};font-size:11px;font-weight:bold;"
                f"padding-bottom:4px;"
            )
        queue_header_l.addWidget(self._queue_label, stretch=1)

        def _queue_icon_button(label, tip):
            b = QPushButton(label)
            b.setToolTip(tip)
            b.setFixedSize(26, 24)
            b.setFocusPolicy(Qt.NoFocus)
            if dojo:
                b.setStyleSheet(
                    f"QPushButton{{background:{card};color:{accent};"
                    f"border:1px solid {border};border-radius:2px;"
                    f"font-size:11px;padding:0;}}"
                    f"QPushButton:hover{{border:1px solid {accent};}}"
                )
            else:
                b.setStyleSheet(
                    f"QPushButton{{background:{card};color:{text};"
                    f"border:1px solid {border};border-radius:5px;"
                    f"font-size:12px;padding:0;}}"
                    f"QPushButton:hover{{background:{surface};}}"
                )
            return b

        self._queue_lock_button = _queue_icon_button("🔒", "Lock queue open")
        self._queue_hide_button = _queue_icon_button("›", "Hide queue")
        self._queue_lock_button.clicked.connect(self._toggle_queue_lock)
        self._queue_hide_button.clicked.connect(self._toggle_queue_drawer)
        queue_header_l.addWidget(self._queue_lock_button)
        queue_header_l.addWidget(self._queue_hide_button)
        if dojo:
            queue_header.setStyleSheet(f"border-bottom:1px solid {border};")
        else:
            queue_header.setStyleSheet(f"border-bottom:1px solid {border};")
        qp_l.addWidget(queue_header)

        self._queue_list = QListWidget()
        self._queue_list.setItemDelegate(QueueDelegate(self._queue_list))
        self._queue_list.setFocusPolicy(Qt.NoFocus)
        self._queue_list.itemClicked.connect(self._on_queue_item_clicked)
        self._queue_list.setStyleSheet(
            f"QListWidget{{background:{surface};border:none;padding:0;}}"
            f"QListWidget::item{{padding:0;}}"
        )
        qp_l.addWidget(self._queue_list, stretch=1)

        self._queue_panel = queue_panel
        self._queue_panel_docked = True
        mid_widget = QWidget()
        mid_l = QHBoxLayout(mid_widget)
        mid_l.setContentsMargins(0, 0, 0, 0)
        mid_l.setSpacing(0)
        mid_l.addWidget(self._canvas_stage, stretch=1)
        mid_l.addWidget(queue_panel)
        self._mid_widget = mid_widget
        self._mid_layout = mid_l
        L.addWidget(mid_widget, stretch=1)

        self._queue_edge_button = QPushButton("‹", self)
        self._queue_edge_button.setToolTip("Show queue")
        self._queue_edge_button.setFocusPolicy(Qt.NoFocus)
        self._queue_edge_button.setStyleSheet(
            f"QPushButton{{background:{accent};color:{bg};"
            f"border:1px solid {border};border-radius:6px;"
            f"font-size:22px;font-weight:bold;padding:0;}}"
            f"QPushButton:hover{{background:white;color:{bg};}}"
        )
        self._queue_edge_button.clicked.connect(self._open_queue_drawer)
        self._queue_edge_button.hide()
        self._apply_queue_drawer_state(recenter=False)

        # ── Bottom bar ────────────────────────────────────────────────────────
        bottom_w = QWidget()
        if dojo:
            bottom_w.setStyleSheet(
                f"background:{surface};border-top:1px solid {border};"
            )
        else:
            bottom_w.setStyleSheet(f"background:{surface};")
        bl = QVBoxLayout(bottom_w)
        bl.setContentsMargins(0, 0, 0, 0)
        bl.setSpacing(0)

        hint_text = (
            "SPACE=REVEAL  •  1/2/3/4=RATE  •  C=FIT  •  D=DEBUG  •  "
            "CTRL+SCROLL=ZOOM  •  H=PAN  •  L=COPY PDF  •  CTRL+L=OPEN FOLDER  •  "
            "ALT/P=PEN  •  X=COLOR  •  +/-=SIZE  •  DEL=CLEAR  •  F11"
            if dojo
            else "Space = reveal  •  1/2/3/4 = rate  •  C = fit+center  •  D = debug  •  "
            "Ctrl+Scroll = zoom  •  H = pan  •  L = copy PDF  •  Ctrl+L = open folder  •  "
            "Alt/P = pen  •  X = color  •  +/- = size  •  Del = clear pen  •  F11"
        )
        hint = QLabel(hint_text)
        self._hint_label = hint
        hint.setAlignment(Qt.AlignCenter)
        hint.setFixedHeight(22)
        if dojo:
            hint.setStyleSheet(
                f"color:{subtext};font-size:7px;"
                f"font-family:{font};letter-spacing:0.5px;"
                f"border-top:1px solid {border};padding:2px;"
            )
        else:
            hint.setStyleSheet(
                f"color:{subtext};font-size:11px;"
                f"border-top:1px solid {border};padding:2px;"
            )
        bl.addWidget(hint)
        self._hint_label = hint
        self._hint_label.hide()

        # ── Waiting state bar ─────────────────────────────────────────────────
        self._wait_bar = QFrame()
        self._wait_bar.setStyleSheet(f"QFrame{{background:{bg};}}")
        wb_l = QVBoxLayout(self._wait_bar)
        wb_l.setContentsMargins(0, 16, 0, 16)
        wb_l.setSpacing(6)
        self._wait_lbl_count = QLabel("")
        self._wait_lbl_count.setAlignment(Qt.AlignCenter)
        if dojo:
            self._wait_lbl_count.setStyleSheet(
                f"color:{accent};font-size:11px;font-weight:bold;"
                f"background:transparent;font-family:{font};letter-spacing:1px;"
            )
        else:
            self._wait_lbl_count.setStyleSheet(
                f"color:{text};font-size:14px;font-weight:bold;background:transparent;"
            )
        self._wait_lbl_countdown = QLabel("")
        self._wait_lbl_countdown.setAlignment(Qt.AlignCenter)
        self._wait_lbl_countdown.setStyleSheet(
            f"color:{subtext};font-size:12px;background:transparent;"
        )
        wb_l.addWidget(self._wait_lbl_count)
        wb_l.addWidget(self._wait_lbl_countdown)
        self._wait_bar.hide()
        bl.addWidget(self._wait_bar)
        L.addWidget(bottom_w)

        # ── Floating overlay: Show Answer button ──────────────────────────────
        self._reveal_bar = QFrame(self._canvas_scroll)
        self._reveal_bar.setStyleSheet("QFrame{background:transparent;border:none;}")
        rb_l = QHBoxLayout(self._reveal_bar)
        rb_l.setContentsMargins(0, 0, 0, 20)
        rb_l.setAlignment(Qt.AlignHCenter | Qt.AlignBottom)
        b_rev = QPushButton("👁  Show Answer  [Space]")
        if dojo:
            b_rev.setStyleSheet(
                f"background:rgba(7,7,11,210);color:{accent};"
                f"border:1px solid {accent};border-radius:2px;"
                f"padding:8px 40px;font-size:9px;font-weight:900;"
                f"font-family:{font};letter-spacing:1px;"
            )
        else:
            b_rev.setStyleSheet(
                f"background:rgba(42,42,62,220);color:{text};"
                f"border:1px solid {border};border-radius:8px;"
                f"padding:8px 40px;font-size:13px;font-weight:bold;"
            )
        b_rev.clicked.connect(self._reveal_current)
        rb_l.addWidget(b_rev)
        self._reveal_bar.hide()

        # ── Floating overlay: Rating buttons ──────────────────────────────────
        self._rating_frame = QFrame(self._canvas_scroll)
        self._rating_frame.setStyleSheet("QFrame{background:transparent;border:none;}")
        rfl = QHBoxLayout(self._rating_frame)
        rfl.setContentsMargins(0, 0, 0, 0)
        rfl.setSpacing(8)
        rfl.setAlignment(Qt.AlignHCenter | Qt.AlignVCenter)

        RATING_COLORS = {
            "danger": ("#FF5555", "#FF8888", "#CC2222"),
            "hard": ("#E08030", "#FFB060", "#B05010"),
            "success": ("#50FA7B", "#80FFB0", "#20C040"),
            "warning": ("#4DC4FF", "#88DDFF", "#1A88CC"),
            "perfect": ("#BD93F9", "#D6B8FF", "#8F5CE6"),
        }
        RATING_COLORS_DOJO = {
            "danger": (p.get("C_RED", "#FF4444"), "#FF7777", "#CC1111"),
            "hard": (p.get("C_ORANGE", "#FF8C00"), "#FFB347", "#CC6600"),
            "success": (p.get("C_GREEN", "#72FF4F"), "#A0FF80", "#44CC20"),
            "warning": (p.get("C_PURPLE", "#A86CFF"), "#C899FF", "#7040CC"),
            "perfect": (p.get("C_YELLOW", "#FFD700"), "#FFE866", "#CCAA00"),
        }

        self._rating_btns = []
        self._prev_lbls = []
        color_map = RATING_COLORS_DOJO if dojo else RATING_COLORS
        for (orig_lbl, obj, q), color_lbl in zip(self.RATINGS, self.RATING_LABELS):
            bg_r, fg_hover, _ = color_map.get(obj, ("#555", "#FFF", "#333"))
            btn = QPushButton(
                f"{orig_lbl.split()[0]}  {orig_lbl.split()[1]}  ?  {color_lbl}"
            )
            btn.setFixedHeight(44 if dojo else 40)
            btn.setMinimumWidth(140)
            if dojo:
                btn.setStyleSheet(
                    f"QPushButton{{background:rgba(7,7,11,200);color:{bg_r};"
                    f"border:1px solid {bg_r};border-radius:2px;"
                    f"font-size:14px;font-weight:900;padding:0 16px;"
                    f"font-family:{font};letter-spacing:0.5px;}}"
                    f"QPushButton:hover{{background:{bg_r};color:{bg};}}"
                )
            else:
                btn.setStyleSheet(
                    f"QPushButton{{background:{bg_r};color:#1E1E2E;"
                    f"border:none;border-radius:8px;"
                    f"font-size:13px;font-weight:bold;padding:0 16px;}}"
                    f"QPushButton:hover{{background:{fg_hover};color:#111;}}"
                )
            btn.clicked.connect(lambda _, qq=q: self._rate(qq))
            rfl.addWidget(btn)
            self._rating_btns.append(btn)
            self._prev_lbls.append((btn, q))

        self._rating_frame.hide()
        self._mid_row_widget = self._reveal_bar

    def _update_ink_hint(self):
        """Canvas toasts handle the visible pen status in review mode."""
        pass

    def _activate_default_review_pen(self):
        canvas = getattr(self, "canvas", None)
        if canvas is None:
            return
        canvas._ink_width = float(getattr(self, "_review_ink_width", 1.2))
        if hasattr(canvas, "ink_set_active"):
            canvas.ink_set_active(True)
        else:
            canvas._ink_active = True

    def _load_review_ink_width(self):
        raw = QSettings("AnkiOcclusion", "App").value("review/ink_width", 1.2)
        try:
            width = float(raw)
        except (TypeError, ValueError):
            width = 1.2
        width = max(0.4, min(12.0, width))
        return width

    def _save_review_ink_width(self):
        width = max(0.4, min(12.0, float(self._review_ink_width)))
        self._review_ink_width = width
        settings = QSettings("AnkiOcclusion", "App")
        settings.setValue("review/ink_width", width)
        settings.sync()

    def _capture_review_ink_width(self, reason=""):
        canvas = getattr(self, "canvas", None)
        if canvas is None:
            return
        self._review_ink_width = float(
            getattr(canvas, "_ink_width", self._review_ink_width)
        )
        self._save_review_ink_width()

    def _toggle_review_mode(self):
        if self._btn_mode.isChecked():
            self._btn_mode.setText("👁 Hide One, Guess One")
            self.canvas.set_review_style("hide_one")
        else:
            self._btn_mode.setText("🟧 Hide All, Guess One")
            self.canvas.set_review_style("hide_all")

    def _on_canvas_zoom_settled(self):
        """Ctrl+scroll zoom settle hone ke baad — user zoom yaad rakho."""
        self._user_zoom_scale = self.canvas._scale

    def _zoom_fit(self):
        vp = self._canvas_scroll.viewport()
        if self.canvas._pages:
            self._pdf_viewer.reset_fit()
            return
        w, h = self.canvas._canvas_wh()
        if w < 1 or h < 1:
            return
        available_w = max(vp.width(), 1)
        self.canvas._scale = available_w / w
        print(
            "[DEBUG][review_image_fit] "
            f"img={w}x{h} viewport={vp.width()}x{vp.height()} "
            f"scale={self.canvas._scale:.4f}"
        )
        self.canvas._on_zoom()

    def _update_review_page_nav_ui(self, *_):
        self._pdf_viewer.refresh_page_ui()
        self._review_ui_page_zero = self._pdf_viewer._ui_page_zero

    def _review_nav_debug(self, action: str, **data):
        return

    def _pdf_quality_debug(self, action: str, **data):
        return

    def _set_review_page_ui(self, current_zero: int):
        self._pdf_viewer.set_page_ui(current_zero)
        self._review_ui_page_zero = self._pdf_viewer._ui_page_zero

    def _on_review_scroll_page_changed(self, value: int):
        page_zero = self.canvas.get_current_page(value)
        if page_zero != self._review_ui_page_zero:
            self._review_nav_debug("scroll", value=value, page=page_zero + 1)
        self._pdf_viewer.set_page_ui(page_zero)
        self._review_ui_page_zero = self._pdf_viewer._ui_page_zero
        self._keep_floating_timer_on_top()

    def _go_to_review_page(self, page_zero: int):
        self._pdf_viewer.go_to_page(page_zero)
        self._review_ui_page_zero = self._pdf_viewer._ui_page_zero
        self._keep_floating_timer_on_top()

    def _finalize_review_page_jump(self, seq: int, target: int):
        self._pdf_viewer._finalize_page_jump(seq, target)
        self._review_ui_page_zero = self._pdf_viewer._ui_page_zero
        self._keep_floating_timer_on_top()

    def _nav_current_review_page(self) -> int:
        return self._pdf_viewer.nav_current_page()

    def _go_prev_review_page(self):
        self._pdf_viewer.go_prev_page()
        self._review_ui_page_zero = self._pdf_viewer._ui_page_zero
        self._keep_floating_timer_on_top()

    def _go_next_review_page(self):
        self._pdf_viewer.go_next_page()
        self._review_ui_page_zero = self._pdf_viewer._ui_page_zero
        self._keep_floating_timer_on_top()

    def _jump_to_review_page_from_input(self):
        self._pdf_viewer.jump_from_input()
        self._review_ui_page_zero = self._pdf_viewer._ui_page_zero
        self._keep_floating_timer_on_top()

    def _center_on_target(self):
        # Force a layout update so viewport dimensions are accurate
        QApplication.processEvents()

        vp = self._canvas_scroll.viewport()
        view_w = vp.width()
        view_h = vp.height()

        # Canvas se scroll position lo — canvas size se calculate hoti hai,
        # scrollbar.maximum() pe depend nahi karta (jo late update hota hai)
        pos = self.canvas.get_target_scroll_pos(view_w, view_h)

        # If target is not set yet (e.g. first load), try to find it from current item
        if pos is None and 0 <= self._idx < len(self._items):
            pos = self.canvas.get_target_scroll_pos(view_w, view_h)

        if pos is None:
            return

        hval, vval = pos
        self._canvas_scroll.horizontalScrollBar().setValue(hval)
        self._canvas_scroll.verticalScrollBar().setValue(vval)

    def _debug_report(self, trigger: str = "manual"):
        """
        Press D in review screen to print a full diagnostic report to terminal.
        Also called automatically on C and Space.

        Covers:
          - Which widget has keyboard focus
          - Canvas scale, size, logical size
          - Viewport size
          - Scroll position (current H/V values and maximums)
          - Target mask rect (scaled) and computed scroll-to position
          - Current card index, box_idx, sm2 state
          - Reveal bar / rating frame visibility
          - PDF path + page count in cache
        """
        import time

        sep = "─" * 60
        vp = self._canvas_scroll.viewport()
        view_w = vp.width()
        view_h = vp.height()
        hsb = self._canvas_scroll.horizontalScrollBar()
        vsb = self._canvas_scroll.verticalScrollBar()
        cw, ch = self.canvas._canvas_wh()
        focused = QApplication.focusWidget()

        lines = [
            "",
            sep,
            f"  🔍 DEBUG REPORT  —  trigger: [{trigger}]  @ {time.strftime('%H:%M:%S')}",
            sep,
            f"  Focus widget    : {type(focused).__name__} (id={id(focused)})",
            f"  Canvas mode     : {self.canvas._mode}",
            f"  Canvas scale    : {self.canvas._scale:.4f}",
            f"  Canvas logical  : {cw} × {ch} px (image-space)",
            f"  Canvas widget   : {self.canvas.width()} × {self.canvas.height()} px (screen)",
            f"  Viewport        : {view_w} × {view_h} px",
            f"  Scroll H        : {hsb.value()} / {hsb.maximum()}",
            f"  Scroll V        : {vsb.value()} / {vsb.maximum()}",
        ]

        # Target mask
        tr = self.canvas.get_target_scaled_rect()
        if tr:
            lines.append(
                f"  Target rect     : x={tr.x():.1f} y={tr.y():.1f} "
                f"w={tr.width():.1f} h={tr.height():.1f}  (screen-space)"
            )
            pos = self.canvas.get_target_scroll_pos(view_w, view_h)
            if pos:
                lines.append(f"  Computed scroll : H={pos[0]}  V={pos[1]}")
        else:
            lines.append(
                f"  Target rect     : None (target_idx={self.canvas._target_idx}, "
                f"group='{self.canvas._target_group_id}')"
            )

        # Current item
        if 0 <= self._idx < len(self._items):
            card, box_idx, sm2_obj = self._items[self._idx]
            lines += [
                f"  Card idx        : {self._idx} / {len(self._items) - 1}",
                f"  Card title      : {card.get('title','?')}",
                f"  Box idx         : {box_idx}",
                f"  SM2 state       : {sm2_obj.get('sched_state','?')}  due={sm2_obj.get('sm2_due','?')}",
                f"  Total boxes     : {len(card.get('boxes', []))}",
            ]
            pdf_path = resolve_asset_path(card.get("pdf_path", ""))
            if pdf_path:
                cached_pages = 0
                for i in range(10000):
                    if PAGE_CACHE.get(pdf_path, i) is None:
                        break
                    cached_pages += 1
                lines.append(f"  PDF path        : {os.path.basename(pdf_path)}")
                lines.append(f"  Cached pages    : {cached_pages}")
            lines.append(f"  Canvas pages    : {len(self.canvas._pages)}")

        # UI state
        lines += [
            f"  Reveal bar      : {'visible' if self._reveal_bar.isVisible() else 'hidden'}",
            f"  Rating frame    : {'visible' if self._rating_frame.isVisible() else 'hidden'}",
            sep,
            "",
        ]

        print("\n".join(lines))
        # Also show as canvas toast so it's visible without terminal
        self.canvas._show_toast(f"📋 Debug report printed to terminal  [{trigger}]")

    def _edit_current_card(self):
        # After session complete _idx == len(_items), use last card
        idx = self._idx
        if idx >= len(self._items):
            idx = len(self._items) - 1
        if not (0 <= idx < len(self._items)):
            return
        card, box_idx, sm2_obj = self._items[idx]
        scroll_pos = self._canvas_scroll.verticalScrollBar().value()
        review_scale = self.canvas._scale
        img_y = scroll_pos / max(review_scale, 0.01)

        # ── O(1) snapshot: box_ids before edit ────────────────────────────────
        before_ids = {
            b.get("box_id", ""): b.get("group_id", "")
            for b in card.get("boxes", [])
            if b.get("box_id")
        }

        dlg = CardEditorDialog(
            self,
            card=dict(card),
            data=self._data,
            initial_scroll=0,
            initial_page=None,
            initial_img_y=img_y,
        )
        self._active_editor = dlg
        dlg.finished.connect(
            lambda result, d=dlg, c=card, b=before_ids: self._finish_edit_current_card(
                d, c, b, result
            )
        )
        dlg.setWindowModality(Qt.ApplicationModal)
        dlg.showFullScreen()
        dlg.show()
        dlg.raise_()
        dlg.activateWindow()

    def _finish_edit_current_card(self, dlg, card, before_ids, result):
        if getattr(self, "_active_editor", None) is dlg:
            self._active_editor = None
        if result != QDialog.Accepted:
            self._user_zoom_scale = None
            self._reload_current_canvas()
            return

        edited = dlg.get_card()

        # [FIX] Preserve SM-2 data on existing boxes — editor returns fresh box
        # dicts that don't have SM-2 fields. If we do card.update(edited) blindly,
        # the new boxes list replaces the old one and all SM-2 state is lost.
        # Solution: merge SM-2 fields from old boxes into edited boxes by box_id.
        old_boxes_by_id = {b.get("box_id", ""): b for b in card.get("boxes", [])}
        SM2_KEYS = (
            "sched_state",
            "sched_step",
            "sm2_interval",
            "sm2_ease",
            "sm2_due",
            "sm2_last_quality",
            "sm2_repetitions",
            "reviews",
        )
        for new_box in edited.get("boxes", []):
            bid = new_box.get("box_id", "")
            if bid and bid in old_boxes_by_id:
                old = old_boxes_by_id[bid]
                for k in SM2_KEYS:
                    if k in old:
                        new_box[k] = old[k]  # preserve SM-2 state

        card.update(edited)
        if self._data:
            store.mark_dirty()

        after_ids = {
            b.get("box_id", ""): b.get("group_id", "")
            for b in card.get("boxes", [])
            if b.get("box_id")
        }

        # ── O(M) Surgical Update: Remove old entries for this card ────────────
        # Pehle is card ke saare purane queue items nikaal dete hain
        # index preserve karne ki zaroorat nahi kyunki queue due-date sorted rehti hai
        self._items = [item for item in self._items if id(item[0]) != id(card)]

        # O(1) tracking sets se bhi purane IDs hatao
        # (Is card ke current boxes ke box_ids/group_ids ko session tracker se saaf karo)
        for bid, gid in before_ids.items():
            self._queued_ids.discard(bid)
            if gid:
                self._queued_ids.discard(gid)

        # ── O(M) detect NEW due boxes → add them to queue ─────────────────────
        seen_new_groups = set()
        for box in card.get("boxes", []):
            bid = box.get("box_id", "")
            gid = box.get("group_id", "")
            track_id = gid if gid else bid
            if not track_id:
                continue

            # Skip if already added (prevents group duplication within this card scan)
            if track_id in seen_new_groups or track_id in self._queued_ids:
                continue

            sm2_init(box)
            if is_due_today(box):
                self._queued_ids.add(track_id)
                if gid:
                    seen_new_groups.add(gid)
                    self._items.append((card, ("group", gid), box))
                else:
                    i = card.get("boxes", []).index(box)
                    self._items.append((card, i, box))

        # Re-sort only if we added/updated items to keep logical flow
        self._items.sort(key=lambda x: x[2].get("sm2_due", ""))
        self.mgr._queue_needs_full_rebuild = True
        self._clear_review_loading_caches()

        # After sort, finished items (future due) are at the end.
        # Find the first item that is still due today (active).
        new_idx = 0
        for i, (_, _, sm2) in enumerate(self._items):
            if is_due_today(sm2):
                new_idx = i
                break
        self._idx = new_idx

        self._user_zoom_scale = None
        self._rebuild_queue()
        self._reload_current_canvas()

    def _open_current_pdf_in_reader(self):
        path = self._current_pdf_path_for_shortcuts()
        if not path:
            self.canvas._show_toast("No PDF loaded for this card")
            return
        idx = self._idx
        if idx >= len(self._items):
            idx = len(self._items) - 1
        if not (0 <= idx < len(self._items)):
            return

        scroll_pos = self._canvas_scroll.verticalScrollBar().value()
        current_page_zero = self.canvas.get_current_page(scroll_pos)
        current_page = current_page_zero + 1
        self._external_pdf_path_hint = path
        self._external_pdf_page_hint = current_page_zero

        try:
            import subprocess

            if sys.platform == "win32":
                xchange_paths = [
                    r"C:\Program Files\Tracker Software\PDF Editor\PDFXEdit.exe",
                    r"C:\Program Files (x86)\Tracker Software\PDF Editor\PDFXEdit.exe",
                    r"C:\Program Files\PDF-XChange\PDF-XChange Editor\PDFXEdit.exe",
                    r"C:\Program Files (x86)\PDF-XChange\PDF-XChange Editor\PDFXEdit.exe",
                ]
                for exe in xchange_paths:
                    if os.path.exists(exe):
                        subprocess.Popen([exe, "/A", f"page={current_page}", path])
                        self.canvas._show_toast(
                            f"📄 Opened p.{current_page} in PDF-XChange"
                        )
                        return

                try:
                    import winreg

                    key = winreg.OpenKey(
                        winreg.HKEY_LOCAL_MACHINE,
                        r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\PDFXEdit.exe",
                    )
                    exe = winreg.QueryValue(key, None)
                    winreg.CloseKey(key)
                    if exe and os.path.exists(exe):
                        subprocess.Popen([exe, "/A", f"page={current_page}", path])
                        self.canvas._show_toast(
                            f"📄 Opened p.{current_page} in PDF-XChange"
                        )
                        return
                except Exception:
                    pass

                os.startfile(path)
                self.canvas._show_toast(
                    "📄 Opened PDF (page jump not supported by this reader)"
                )

            elif sys.platform == "darwin":
                subprocess.Popen(["open", path])
                self.canvas._show_toast(f"📄 Opened PDF p.{current_page}")
            else:
                subprocess.Popen(["xdg-open", path])
                self.canvas._show_toast(f"📄 Opened PDF p.{current_page}")

        except Exception as ex:
            QMessageBox.warning(
                self, "Could not open PDF", f"Could not open PDF:\n{ex}"
            )

    def _current_pdf_path_for_shortcuts(self):
        idx = self._idx
        if idx >= len(self._items):
            idx = len(self._items) - 1
        if not (0 <= idx < len(self._items)):
            return ""
        card, _, _ = self._items[idx]
        path = resolve_asset_path(card.get("pdf_path", ""))
        if not path or not os.path.exists(path):
            return ""
        return path

    def _copy_current_pdf_file_to_clipboard(self):
        path = self._current_pdf_path_for_shortcuts()
        if not path:
            self.canvas._show_toast("No PDF loaded for this card")
            return
        mime = QMimeData()
        mime.setUrls([QUrl.fromLocalFile(path)])
        QApplication.clipboard().setMimeData(mime)
        print(f"[DEBUG][review_pdf_shortcut] copied_file {path}")
        self.canvas._show_toast("Copied PDF file")

    def _reveal_current_pdf_in_folder(self):
        path = self._current_pdf_path_for_shortcuts()
        if not path:
            self.canvas._show_toast("No PDF loaded for this card")
            return
        try:
            import subprocess

            if sys.platform == "win32":
                subprocess.Popen(["explorer", "/select,", os.path.normpath(path)])
            elif sys.platform == "darwin":
                subprocess.Popen(["open", "-R", path])
            else:
                QDesktopServices.openUrl(QUrl.fromLocalFile(os.path.dirname(path)))
            print(f"[DEBUG][review_pdf_shortcut] reveal_path {path}")
            self.canvas._show_toast("Opened PDF folder")
        except Exception as ex:
            QMessageBox.warning(
                self, "Could not open location", f"Could not open PDF location:\n{ex}"
            )

    def _open_annotation_beta(self):
        idx = self._idx
        if idx >= len(self._items):
            idx = len(self._items) - 1
        if not (0 <= idx < len(self._items)):
            return
        card, _box_idx, _ = self._items[idx]
        path = resolve_asset_path(card.get("pdf_path", ""))
        if not path or not os.path.exists(path):
            QMessageBox.warning(self, "No PDF", "No PDF is currently loaded.")
            return
        page_zero = self.canvas.get_current_page(
            self._canvas_scroll.verticalScrollBar().value()
        )
        scroll_y = self._canvas_scroll.verticalScrollBar().value()
        review_scale = max(float(getattr(self.canvas, "_scale", 1.0) or 1.0), 0.01)
        img_y = float(scroll_y) / review_scale
        print(
            f"[DEBUG][review_annotation] handoff "
            f"page={page_zero + 1} scroll_y={scroll_y} scale={review_scale:.4f} img_y={img_y:.2f}"
        )
        active_dialog = self.__dict__.get("_active_annotation_dialog")
        if active_dialog is not None and active_dialog.isVisible():
            active_dialog.raise_()
            active_dialog.activateWindow()
            return
        dialog = PdfAnnotationDialog(
            path,
            parent=None,
            initial_page=page_zero,
            initial_anchor_y=img_y,
        )
        self._active_annotation_dialog = dialog
        dialog.finished.connect(
            lambda result, d=dialog, p=path: self._finish_annotation_beta(
                d, p, result
            )
        )
        self._pause_review_lazy_activity_for_annotation()
        self._prepare_annotation_window(dialog)
        dialog.showMaximized()
        dialog.raise_()
        dialog.activateWindow()

    def _annotation_window_flags(self):
        return (
            Qt.Window
            | Qt.WindowTitleHint
            | Qt.WindowSystemMenuHint
            | Qt.WindowMinimizeButtonHint
            | Qt.WindowMaximizeButtonHint
            | Qt.WindowCloseButtonHint
        )

    def _prepare_annotation_window(self, dialog):
        dialog.setParent(None, Qt.Window)
        dialog.setWindowFlags(self._annotation_window_flags())
        dialog.setWindowModality(Qt.NonModal)
        dialog.setAttribute(Qt.WA_DeleteOnClose, False)
        try:
            dialog.setWindowIcon(self.window().windowIcon())
        except Exception:
            pass
        self._install_annotation_switch_shortcuts(dialog)

    def _install_annotation_switch_shortcuts(self, dialog):
        try:
            review_shortcut = QShortcut(QKeySequence("Ctrl+Tab"), self)
            review_shortcut.setContext(Qt.WindowShortcut)
            review_shortcut.activated.connect(self._focus_active_annotation_window)
            self._annotation_focus_shortcut = review_shortcut

            dialog_shortcut = QShortcut(QKeySequence("Ctrl+Tab"), dialog)
            dialog_shortcut.setContext(Qt.WindowShortcut)
            dialog_shortcut.activated.connect(self._focus_review_window)
            dialog._review_focus_shortcut = dialog_shortcut
        except Exception:
            pass

    def _focus_active_annotation_window(self):
        dialog = self.__dict__.get("_active_annotation_dialog")
        if dialog is None or not dialog.isVisible():
            return
        if dialog.isMinimized():
            dialog.showNormal()
        dialog.raise_()
        dialog.activateWindow()

    def _focus_review_window(self):
        win = self.window()
        if win.isMinimized():
            win.showNormal()
        win.raise_()
        win.activateWindow()

    def _finish_annotation_beta(self, dialog, path: str, result):
        if self.__dict__.get("_active_annotation_dialog") is dialog:
            self._active_annotation_dialog = None
            self._annotation_focus_shortcut = None
        self._resume_review_lazy_activity_after_annotation(path)
        self._apply_annotation_beta_refresh(
            path,
            getattr(dialog, "_saved_pages", []),
            getattr(dialog, "return_page", None),
        )

    def _pause_review_lazy_activity_for_annotation(self):
        self._review_lazy_trace_suspended = True
        timer = getattr(self, "_ui_idle_timer", None)
        if timer is not None:
            timer.stop()
        self._background_fill_state = None
        self._bg_pending_inserts.clear()
        self._pending_visible_request = False
        self._stop_ondemand_thread()
        watcher = self.__dict__.get("_pdf_watcher")
        if watcher is not None:
            watcher.stop_watch()

    def _resume_review_lazy_activity_after_annotation(self, path: str | None = None):
        self._review_lazy_trace_suspended = False
        if path:
            watcher = self.__dict__.get("_pdf_watcher")
            if watcher is not None:
                watcher.watch_pdf(path)

    def _clear_review_loading_caches(self):
        self.__dict__.setdefault("_review_priority_pages_cache", {}).clear()
        self.__dict__.setdefault("_review_adapted_boxes_cache", {}).clear()

    def _review_box_signature(self, boxes):
        sig = []
        for box in boxes or []:
            rect = box.get("rect", ())
            if isinstance(rect, (list, tuple)):
                rect_sig = tuple(rect[:4])
            else:
                rect_sig = repr(rect)
            sig.append(
                (
                    box.get("box_id", ""),
                    box.get("group_id", ""),
                    rect_sig,
                    box.get("shape", "rect"),
                    box.get("angle", 0.0),
                    box.get("page_num"),
                )
            )
        return tuple(sig)

    def _adapt_review_boxes(self, card, path):
        boxes = card.get("boxes", []) or []
        if not path or not boxes:
            return boxes

        source_zoom = card.get("_pdf_box_render_zoom", PDF_LEGACY_BOX_ZOOM)
        try:
            source_zoom_key = float(source_zoom)
        except (TypeError, ValueError):
            source_zoom_key = float(PDF_LEGACY_BOX_ZOOM)
        try:
            target_zoom_key = float(self._pdf_render_zoom)
        except (TypeError, ValueError):
            target_zoom_key = 0.0
        cache = self.__dict__.setdefault("_review_adapted_boxes_cache", {})
        key = (
            id(card),
            os.path.abspath(path),
            source_zoom_key,
            target_zoom_key,
            self._review_box_signature(boxes),
        )
        cached = cache.get(key)
        if cached is None:
            cached = adapt_pdf_boxes_to_render_zoom(
                path,
                boxes,
                source_zoom,
                self._pdf_render_zoom,
            )
            cache[key] = cached
            while len(cache) > 32:
                cache.pop(next(iter(cache)))
        return copy.deepcopy(cached)

    def _start_review_lazy_trace(self, page_nums, ttl_seconds: float = 8.0):
        pages = {int(page_num) for page_num in (page_nums or [])}
        if not pages:
            self._review_lazy_trace_pages = set()
            self._review_lazy_trace_seen_pages = set()
            self._review_lazy_trace_until = 0.0
            return
        self._review_lazy_trace_pages = pages
        self._review_lazy_trace_seen_pages = set()
        self._review_lazy_trace_until = time.monotonic() + max(0.5, float(ttl_seconds))

    def _apply_annotation_beta_refresh(
        self, path: str, changed_pages, return_page: int | None
    ):
        if not changed_pages:
            self._trigger_center_fit()
            return
        refreshed_pages = sorted(set(int(pn) for pn in changed_pages))
        self._start_review_lazy_trace(refreshed_pages)
        key = os.path.abspath(path)
        if "_suppress_pdf_reload_until" not in self.__dict__:
            self._suppress_pdf_reload_until = {}
        self._suppress_pdf_reload_until[key] = time.monotonic() + 2.5
        self._pdf_watcher.ignore_next_change(path, count=3)
        print(
            "[DEBUG][review_after_edit] "
            + ", ".join(f"p.{page_num + 1}" for page_num in refreshed_pages)
        )
        for page_num in refreshed_pages:
            px = PAGE_CACHE.get(path, page_num)
            if px is not None and not px.isNull():
                self._debug_review_lazy_page_loaded(
                    source="render", page_num=page_num, pixmap=px
                )
                self.canvas.inject_page(page_num, px)
        self._update_review_page_nav_ui()
        self._trigger_center_fit()

    def _reload_current_canvas(self, view_idx=None):
        """
        STEP 4 — Skeleton-first lazy loading.

        Flow:
          1. Image card      → unchanged (direct QPixmap load)
          2. PDF             → always skeleton-first lazy path:
               a. load_pdf_skeleton() — grey placeholders, ~5ms
               b. canvas ready instantly with correct layout + page_tops
               c. _start_priority_render() — queue pages first
               d. scroll → _on_visible_pages_changed() → on-demand rest
          3. PDF missing     → grey fallback (unchanged)

        Terminal prints every decision point.
        """
        if view_idx is None:
            view_idx = self._idx

        if not (0 <= view_idx < len(self._items)):
            return
        card, box_idx, _ = self._items[view_idx]
        self._bg_pending_inserts.clear()
        self._pending_skeleton_result = None
        self._close_bg_prefetch_dialog()
        self._stop_skeleton_thread()

        import time

        t_start = time.perf_counter()
        display_path = resolve_asset_path(
            card.get("pdf_path", "") or card.get("image_path", "?")
        )
        fname = os.path.basename(display_path)

        # ── 1. IMAGE CARD ─────────────────────────────────────────────────────
        image_path = resolve_asset_path(card.get("image_path", ""))
        if card.get("image_path") and os.path.exists(image_path):
            px = QPixmap(image_path)
            if px and not px.isNull():
                self._apply_canvas(card, box_idx, px)
            return

        # ── 2. PDF CARD ───────────────────────────────────────────────────────
        if card.get("pdf_path") and PDF_SUPPORT:
            path = resolve_asset_path(card.get("pdf_path", ""))
            self._pdf_watcher.watch_pdf(path)

            # ── 2a. PDF missing ───────────────────────────────────────────────
            if not os.path.exists(path):
                self._canvas_pdf_path = ""  # FIX 1: kills stale thread signals
                self.canvas.load_pixmap(QPixmap())
                boxes = card.get("boxes", [])
                if boxes:
                    display_boxes = [{**b, "revealed": False} for b in boxes]
                    self.canvas.set_boxes_with_state(display_boxes)
                    tgt = box_idx if isinstance(box_idx, int) else -1
                    self.canvas.set_target_box(tgt)
                    self.canvas.set_mode("review")
                    self.canvas._show_toast(
                        "PDF not found — Edit Card > Relink PDF to fix"
                    )
                self._show_overlay(self._reveal_bar)
                self._rating_frame.hide()
                self.setFocus()
                return

            # ── 2b. Review always stays queue-first lazy, even if the disk cache
            #        already has every page. We do not hydrate the whole PDF into
            #        the review canvas upfront anymore.
            total_pages = get_pdf_page_count(path)
            self._pdf_render_zoom = choose_pdf_render_zoom(total_pages)
            previous_zoom = PAGE_CACHE.get_render_zoom(path)
            cached_before = (
                PAGE_CACHE.cached_page_count(path, total_pages)
                if hasattr(PAGE_CACHE, "cached_page_count")
                else "?"
            )
            profile_reset = ensure_pdf_cache_profile(path, self._pdf_render_zoom)
            cached_after = (
                PAGE_CACHE.cached_page_count(path, total_pages)
                if hasattr(PAGE_CACHE, "cached_page_count")
                else "?"
            )
            print(
                "[DEBUG][review_cache_profile] "
                f"file={fname} pages={total_pages} "
                f"previous_zoom={previous_zoom} target_zoom={self._pdf_render_zoom} "
                f"reset_cache={profile_reset} "
                f"cached_before={cached_before}/{total_pages} "
                f"cached_after={cached_after}/{total_pages}"
            )
            self._pdf_quality_debug(
                "profile",
                pages=total_pages,
                zoom=self._pdf_render_zoom,
                reset_cache=profile_reset,
            )

            # ── 2c. NEW LAZY PATH — skeleton first ────────────────────────────
            self._pending_skeleton_result = {
                "card": card,
                "box_idx": box_idx,
                "clean_pages": {},
                "path": path,
                "t_start": t_start,
            }
            self._start_review_skeleton_thread(path)
            return

        # ── 3. FALLBACK — no image, no pdf ────────────────────────────────────

    # ── STEP 4 HELPERS ────────────────────────────────────────────────────────

    @staticmethod
    def _fmt_review_pages(page_nums, max_items: int = 10):
        pages = [int(pn) for pn in (page_nums or [])]
        if not pages:
            return "none"
        shown = ", ".join(f"p.{pn + 1}" for pn in pages[:max_items])
        if len(pages) > max_items:
            shown += f", ... (+{len(pages) - max_items})"
        return shown

    def _card_review_pages(self, card, box_ref, path=None):
        c_boxes = card.get("boxes", [])
        selected_boxes = []
        if isinstance(box_ref, tuple) and box_ref[0] == "group":
            gid = box_ref[1]
            selected_boxes = [b for b in c_boxes if b.get("group_id") == gid]
        elif isinstance(box_ref, int) and 0 <= box_ref < len(c_boxes):
            selected_boxes = [c_boxes[box_ref]]
        needs_page_inference = any(
            box.get("page_num") is None for box in selected_boxes
        )
        if path and needs_page_inference and "_pdf_render_zoom" in self.__dict__:
            c_boxes = self._adapt_review_boxes(card, path)
        pages = []
        if isinstance(box_ref, tuple) and box_ref[0] == "group":
            gid = box_ref[1]
            for box in c_boxes:
                if box.get("group_id") == gid:
                    pn = box.get("page_num")
                    if pn is not None:
                        pages.append(pn)
        elif isinstance(box_ref, int) and 0 <= box_ref < len(c_boxes):
            pn = c_boxes[box_ref].get("page_num")
            if pn is not None:
                pages.append(pn)
        return pages

    def _get_priority_pages(self, card, box_idx, total_pages, path=None):
        """
        Return only the queued review pages from this same PDF.
        These pages render FIRST so the viewport stays responsive while the
        current review session is warming up.

        The goal is simple:
          1. current mask page
          2. other review pages from the same PDF
        Everything else stays lazy and scroll-driven.
        """
        card_path = resolve_asset_path(path or card.get("pdf_path", ""))
        cache_key = (
            os.path.abspath(card_path) if card_path else "",
            id(card),
            repr(box_idx),
            int(total_pages or 0),
        )
        priority_cache = self.__dict__.setdefault("_review_priority_pages_cache", {})
        cached = priority_cache.get(cache_key)
        if cached is not None:
            return list(cached)

        def _clean(page_nums):
            result = []
            seen = set()
            for pn in page_nums or []:
                if pn is None:
                    continue
                pn = max(0, min(int(pn), max(0, int(total_pages) - 1)))
                if pn in seen:
                    continue
                seen.add(pn)
                result.append(pn)
            return result

        raw_current_pages = _clean(self._card_review_pages(card, box_idx))
        current_pages = _clean(self._card_review_pages(card, box_idx, card_path))
        if current_pages and current_pages != raw_current_pages:
            print(
                "[DEBUG][review_queue_pages] "
                f"inferred_current={self._fmt_review_pages(current_pages)} "
                f"raw={self._fmt_review_pages(raw_current_pages)}"
            )
        session_pages = []
        # Preload every due page from the same PDF that is already in this
        # review session. This keeps the current PDF warm without fanning out
        # into a full-document background fill.
        if card_path:
            for c, box_ref, _sm2 in self._items:
                if resolve_asset_path(c.get("pdf_path", "")) != card_path:
                    continue
                session_pages.extend(self._card_review_pages(c, box_ref, card_path))

        # Current box page(s) must come first, even if they are far past the
        # RAM cache limit. The rest is only a small warmup window.
        ordered = current_pages + sorted(_clean(session_pages))
        result = _clean(ordered)
        if len(result) > self.PRIORITY_PAGE_LIMIT:
            result = result[: self.PRIORITY_PAGE_LIMIT]
        if result:
            print(
                "[DEBUG][review_queue_pages] "
                f"current={self._fmt_review_pages(current_pages)} "
                f"priority={self._fmt_review_pages(result)} "
                f"limit={self.PRIORITY_PAGE_LIMIT}"
            )
        else:
            print("[DEBUG][review_queue_pages] priority none")
        priority_cache[cache_key] = tuple(result)
        while len(priority_cache) > 16:
            priority_cache.pop(next(iter(priority_cache)))
        return result

    def _stop_skeleton_thread(self):
        if self._skeleton_thread and self._skeleton_thread.isRunning():
            self._skeleton_thread.stop()
            self._skeleton_thread.quit()
            self._skeleton_thread.wait(500)
        self._skeleton_thread = None

    def _start_review_skeleton_thread(self, path):
        self._stop_skeleton_thread()
        self._skeleton_thread = PdfSkeletonThread(
            path, zoom=self._pdf_render_zoom, parent=self
        )
        self._skeleton_thread.done.connect(
            lambda skel, p=path: self._on_review_skeleton_ready(p, skel)
        )
        self._skeleton_thread.error.connect(
            lambda err, p=path: self._on_review_skeleton_error(p, err)
        )
        self._skeleton_thread.start()

    def _on_review_skeleton_error(self, path, err):
        pending = self._pending_skeleton_result
        if not pending or pending.get("path") != path:
            return
        card = pending.get("card")
        box_idx = pending.get("box_idx")
        self._pending_skeleton_result = None
        self._start_review_pdf_thread(card, box_idx)

    def _on_review_skeleton_ready(self, path, skel):
        pending = self._pending_skeleton_result
        if not pending or pending.get("path") != path:
            return
        self._pending_skeleton_result = None
        if not skel or getattr(skel, "error", None):
            self._on_review_skeleton_error(
                path, getattr(skel, "error", "Could not build PDF skeleton")
            )
            return
        self._apply_review_skeleton_result(
            pending["card"],
            pending["box_idx"],
            pending["clean_pages"],
            path,
            skel,
            pending["t_start"],
        )

    def _apply_review_skeleton_result(
        self, card, box_idx, clean_pages, path, skel, t_start
    ):
        pages = (
            list(skel.placeholders)
            if getattr(skel, "placeholders", None)
            else build_skeleton_placeholders(getattr(skel, "page_dims", []))
        )
        for i, pg in clean_pages.items():
            if 0 <= i < len(pages):
                pages[i] = pg
        if clean_pages:
            cached_idxs = sorted(clean_pages.keys())
            self._debug_review_lazy_pages_loaded(source="cache", page_nums=cached_idxs)
        self._apply_canvas_pages(card, box_idx, pages)
        self._review_canvas_real_pages = {int(i) for i in clean_pages.keys()}
        self._review_render_inflight_pages = set()
        self.canvas._show_toast(f"⏳ Loading p.1–{skel.total_pages}...")
        t_skel_ms = (time.perf_counter() - t_start) * 1000

        priority_pages = self._get_priority_pages(card, box_idx, skel.total_pages, path)
        print(
            "[DEBUG][review_load] "
            f"skeleton_ready pages={skel.total_pages} "
            f"cache_ram_limit={getattr(PAGE_CACHE, '_max_pages', '?')} "
            f"priority_count={len(priority_pages)} "
            f"priority={self._fmt_review_pages(priority_pages)} "
            f"t={t_skel_ms:.1f}ms"
        )
        self._start_priority_render(path, priority_pages, skel.total_pages)
        self._wire_scroll_ondemand(path, skel.total_pages)

    def _start_priority_render(self, path, priority_pages, total_pages):
        """
        Launch PdfOnDemandThread for priority pages.
        On each page_ready → canvas.inject_page().
        Non-priority pages stay lazy until they become visible.

        FIX 1: We stamp self._canvas_pdf_path = path here.
        _on_page_ready checks this stamp before injecting —
        if user switched card mid-render, stamp changes and
        stale signals are silently dropped. No more 'canvas has 0 pages'.
        """
        self._stop_ondemand_thread()
        self._ondemand_kind = "priority"
        self._background_fill_state = None
        self._bg_pending_inserts.clear()
        self._priority_pages = set(priority_pages)

        # ── FIX 1: stamp current PDF path on canvas ───────────────────────────
        # This is the guard key — _on_page_ready compares against this.
        self._canvas_pdf_path = path
        self.canvas._current_pdf_path = path

        cached_priority_pages = {}
        to_render = []
        for page_num in priority_pages:
            cached_page = PAGE_CACHE.get(path, page_num)
            if cached_page is not None and not cached_page.isNull():
                cached_priority_pages[page_num] = cached_page
            else:
                to_render.append(page_num)
        self._review_render_inflight_pages = set(int(p) for p in to_render)

        # Inject already-cached pages immediately (no thread needed)
        for pn, pg in cached_priority_pages.items():
            if pg and not pg.isNull():
                self._debug_review_lazy_page_loaded(
                    source="cache",
                    page_num=pn,
                    pixmap=pg,
                    kind="priority",
                    canvas_wh=f"{self.canvas.width()}x{self.canvas.height()}px",
                )
                self.canvas.inject_page(pn, pg)
                self.__dict__.setdefault("_review_canvas_real_pages", set()).add(
                    int(pn)
                )
                self._debug_review_page_injection(
                    page_num=pn, injected=True, kind="priority"
                )

        if not to_render:
            self._background_fill_state = None
            self._ondemand_kind = None
            return

        print(
            "[DEBUG][review_priority] "
            f"start render={self._fmt_review_pages(to_render)} "
            f"cached={self._fmt_review_pages(cached_priority_pages.keys())}"
        )
        self._ondemand_thread = PdfOnDemandThread(
            path, to_render, zoom=self._pdf_render_zoom, parent=self
        )
        self._ondemand_path = path
        self._ondemand_total = total_pages
        self._ondemand_kind = "priority"
        self._ondemand_requested_pages = set(int(p) for p in to_render)

        self._ondemand_thread.page_ready.connect(self._on_page_ready)
        self._ondemand_thread.batch_done.connect(
            lambda rendered: self._on_priority_batch_done(
                path, priority_pages, total_pages
            )
        )
        self._ondemand_thread.error.connect(lambda err: None)
        self._ondemand_thread.start()

    def _on_priority_batch_done(self, path, priority_pages, total_pages):
        requested = set(self.__dict__.pop("_ondemand_requested_pages", set()) or set())
        self.__dict__.setdefault("_review_render_inflight_pages", set()).difference_update(
            requested
        )
        self._background_fill_state = None
        self._ondemand_kind = None
        pending = self._pending_visible_request
        self._pending_visible_request = None
        print(
            "[DEBUG][review_priority] "
            f"done requested={self._fmt_review_pages(requested)} "
            f"pending_visible={self._fmt_review_pages(pending[1] if pending else [])}"
        )
        if pending and pending[0] == getattr(self, "_ondemand_path", None):
            pending_path, pending_pages = pending
            fresh_needed = self._review_pages_needing_render(
                pending_path,
                pending_pages,
                context="after_priority",
            )
            if fresh_needed:
                self._start_visible_page_request(pending_path, fresh_needed)

    # ── LRU window size for background fill ───────────────────────────────────
    # Background fill renders at most this many pages beyond priority set.
    # Keeps RAM bounded even for huge PDFs.
    # On-demand scroll handles anything outside this window.
    _BG_FILL_WINDOW = 15

    # Background fill runs in small batches so it can yield to scroll-driven
    # visible-page loads instead of monopolizing the render thread.
    _BG_FILL_BATCH = 2
    _BG_FILL_DELAY_MS = 250

    def _canvas_alive(self):
        canvas = getattr(self, "canvas", None)
        if canvas is None:
            return False
        try:
            canvas.objectName()
            return True
        except RuntimeError:
            return False

    def _safe_canvas_toast(self, msg):
        if not self._canvas_alive():
            print(f"[DEBUG][review_bg] toast_skip reason=canvas_deleted msg={msg}")
            return
        try:
            self.canvas._show_toast(msg)
        except RuntimeError as exc:
            print(f"[DEBUG][review_bg] toast_skip reason=qt_deleted error={exc}")

    def _queue_background_ready(self, path, rendered):
        if path != getattr(self, "_canvas_pdf_path", None):
            print(f"[DEBUG][review_bg] stale_ready_skip path={path}")
            return
        ready = [pn for pn in rendered if PAGE_CACHE.get(path, pn) is not None]
        if not ready:
            return
        for pn in ready:
            cached = PAGE_CACHE.get(path, pn)
            if cached and not cached.isNull():
                self._bg_pending_inserts[pn] = cached
        self._bg_prefetch_rendered_count += len(ready)
        total = self._bg_prefetch_total_pages or max(
            self._bg_prefetch_rendered_count, 1
        )
        self._bg_prefetch_cached_count = min(
            self._bg_prefetch_cached_count + len(ready), total
        )
        msg = "BG ready: " + ", ".join(f"p.{pn+1}" for pn in sorted(ready))
        self._safe_canvas_toast(msg)
        self._note_user_activity()

    def _flush_pending_background_inserts(self):
        if not self._bg_pending_inserts:
            return
        current_path = getattr(self, "_canvas_pdf_path", None)
        if not current_path:
            self._bg_pending_inserts.clear()
            return
        if self._pending_visible_request:
            self._ui_idle_timer.start()
            return
        if (
            self._ondemand_thread
            and self._ondemand_thread.isRunning()
            and getattr(self, "_ondemand_kind", None) == "visible"
        ):
            self._ui_idle_timer.start()
            return
        if (
            self._ondemand_thread
            and self._ondemand_thread.isRunning()
            and getattr(self, "_ondemand_kind", None) == "background"
        ):
            # let the background render continue, but flush only on idle timeout
            return
        if not self._canvas_alive():
            print("[DEBUG][review_bg] insert_skip reason=canvas_deleted")
            self._bg_pending_inserts.clear()
            return
        # The old prefetch-accept dialog was removed, so background-ready pages
        # must auto-insert as soon as the UI is idle instead of waiting on a
        # flag that no longer has a user-facing control.
        ready_items = sorted(self._bg_pending_inserts.items())
        self._bg_pending_inserts.clear()
        for pn, pg in ready_items:
            pg = self._coerce_page_pixmap(pg)
            if pg is None:
                continue
            self._debug_review_lazy_page_loaded(
                source="cache",
                page_num=pn,
                pixmap=pg,
                kind="background",
                canvas_wh=f"{self.canvas.width()}x{self.canvas.height()}px",
            )
            self.canvas.inject_page(pn, pg)
            self.__dict__.setdefault("_review_canvas_real_pages", set()).add(int(pn))
            self._debug_review_page_injection(
                page_num=pn, injected=True, kind="background"
            )
        if ready_items:
            self._safe_canvas_toast(
                "Inserted " + ", ".join(f"p.{pn+1}" for pn, _ in ready_items)
            )

    def _start_background_fill(self, path, already_rendered, total_pages):
        if path != getattr(self, "_canvas_pdf_path", None):
            print(f"[DEBUG][review_bg] start_skip reason=stale_path path={path}")
            return
        if not self._canvas_alive():
            print("[DEBUG][review_bg] start_skip reason=canvas_deleted")
            return
        cached_pages = sum(
            1
            for page_num in range(total_pages)
            if PAGE_CACHE.get(path, page_num) is not None
        )
        self._bg_accept_mode = False
        self._bg_prefetch_total_pages = total_pages
        self._bg_prefetch_cached_count = cached_pages
        self._bg_prefetch_rendered_count = len(already_rendered)
        self._show_bg_prefetch_dialog(path, total_pages)
        self._sync_bg_prefetch_dialog(path, total_pages, done=False)
        self._safe_canvas_toast(f"Ready: {cached_pages}/{total_pages} pages cached")

        # Defer if a visible-page request is in flight. Scroll responsiveness
        # wins over background cache completion.
        if self._ondemand_thread and self._ondemand_thread.isRunning():
            if getattr(self, "_ondemand_kind", None) == "visible":
                self._background_fill_state = (
                    path,
                    list(already_rendered),
                    total_pages,
                )
                return
            if getattr(self, "_ondemand_kind", None) == "background":
                return

        # ?? FIX 1 guard: if card switched, abort ?????????????????????????????
        if getattr(self, "_canvas_pdf_path", None) != path:
            return

        all_pages = set(range(total_pages))
        canvas_real = set(self.__dict__.get("_review_canvas_real_pages", set()) or set())
        pending_bg = set((self.__dict__.get("_bg_pending_inserts", {}) or {}).keys())
        skip = set(already_rendered) | {
            p for p in all_pages if PAGE_CACHE.get(path, p) is not None
        } | canvas_real | pending_bg
        remaining = sorted(all_pages - skip)

        if not remaining:
            self._safe_canvas_toast(f"PDF ready: {total_pages} pages")
            self._background_fill_state = None
            self._ondemand_kind = None
            self._bg_accept_mode = True
            self._sync_bg_prefetch_dialog(path, total_pages, done=True)
            return

        priority_pages = set(getattr(self, "_priority_pages", set()) or set())
        background_done = set(already_rendered) - priority_pages
        remaining_slots = max(0, self._BG_FILL_WINDOW - len(background_done))
        if remaining_slots <= 0:
            self._background_fill_state = None
            self._ondemand_kind = None
            return

        windowed = remaining[: min(self._BG_FILL_BATCH, remaining_slots)]
        next_rendered = sorted(set(already_rendered) | set(windowed))

        self._stop_ondemand_thread()
        self._ondemand_kind = "background"
        self._background_fill_state = (path, next_rendered, total_pages)

        # Verify canvas is still intact after stop (regression check for the wipe bug)
        if not self._canvas_alive():
            print("[DEBUG][review_bg] start_skip reason=canvas_deleted")
            return
        canvas_pages_after_stop = len(self.canvas._pages)
        if canvas_pages_after_stop == 0:
            return

        self._ondemand_thread = PdfOnDemandThread(
            path, windowed, zoom=self._pdf_render_zoom, parent=self
        )
        self._ondemand_path = path
        self._ondemand_total = total_pages
        self._ondemand_kind = "background"
        self._review_render_inflight_pages = set(int(p) for p in windowed)
        self._ondemand_requested_pages = set(int(p) for p in windowed)
        print(
            "[DEBUG][review_bg] "
            f"start window={self._fmt_review_pages(windowed)} "
            f"remaining={len(remaining)} slots={remaining_slots}"
        )

        self._ondemand_thread.page_ready.connect(self._on_page_ready)
        self._ondemand_thread.batch_done.connect(
            lambda rendered, p=path, ar=next_rendered, tp=total_pages: self._on_background_fill_batch_done(
                rendered, p, ar, tp
            )
        )
        self._ondemand_thread.error.connect(lambda err: None)
        self._ondemand_thread.start()

    def _on_background_fill_batch_done(
        self, rendered, path, already_rendered, total_pages
    ):
        requested = set(self.__dict__.pop("_ondemand_requested_pages", set()) or set())
        self.__dict__.setdefault("_review_render_inflight_pages", set()).difference_update(
            requested
        )
        if path != getattr(self, "_canvas_pdf_path", None):
            print(f"[DEBUG][review_bg] batch_skip reason=stale_path path={path}")
            self._background_fill_state = None
            self._ondemand_kind = None
            return
        combined = sorted(set(already_rendered) | set(rendered))
        self._queue_background_ready(path, rendered)
        canvas_real = set(self.__dict__.get("_review_canvas_real_pages", set()) or set())
        pending_bg = set((self.__dict__.get("_bg_pending_inserts", {}) or {}).keys())
        remaining = [
            pn
            for pn in range(total_pages)
            if PAGE_CACHE.get(path, pn) is None
            and pn not in combined
            and pn not in canvas_real
            and pn not in pending_bg
        ]

        if remaining:
            self._background_fill_state = (path, combined, total_pages)
            self._ondemand_kind = None
            self._sync_bg_prefetch_dialog(path, total_pages, done=False)
            print(
                "[DEBUG][review_bg] "
                f"batch_done rendered={self._fmt_review_pages(rendered)} "
                f"requested={self._fmt_review_pages(requested)} "
                f"remaining={len(remaining)}"
            )
            self._ui_idle_timer.start(self._BG_FILL_DELAY_MS)
            return

        self._background_fill_state = None
        self._ondemand_kind = None
        self._bg_accept_mode = True
        self._sync_bg_prefetch_dialog(path, total_pages, done=True)
        print(
            "[DEBUG][review_bg] "
            f"done rendered={self._fmt_review_pages(rendered)} "
            f"requested={self._fmt_review_pages(requested)}"
        )
        self._safe_canvas_toast(f"PDF ready: {total_pages} pages")

    def _wire_scroll_ondemand(self, path, total_pages):
        """
        Connect scroll area's visible_pages_changed signal → on-demand render.
        Safe to call multiple times — disconnects old connection first.
        """
        try:
            self._canvas_scroll.visible_pages_changed.disconnect(
                self._on_visible_pages_changed
            )
        except Exception:
            pass  # not connected yet — fine

        # Store path+total for use in the slot
        self._ondemand_path = path
        self._ondemand_total = total_pages
        self._visible_debug_seen_pages = set()

        self._canvas_scroll.visible_pages_changed.connect(
            self._on_visible_pages_changed
        )

    def _review_pages_needing_render(self, path, page_nums, context="visible"):
        real_pages = set(self.__dict__.get("_review_canvas_real_pages", set()) or set())
        pending_bg = set((self.__dict__.get("_bg_pending_inserts", {}) or {}).keys())
        inflight = set(
            self.__dict__.get("_review_render_inflight_pages", set()) or set()
        )
        pending = self.__dict__.get("_pending_visible_request")
        pending_visible = (
            set(int(pn) for pn in (pending[1] or []))
            if pending and pending[0] == path
            else set()
        )
        needed = []
        skipped = {
            "canvas_real": 0,
            "pending_bg": 0,
            "inflight": 0,
            "pending_visible": 0,
            "cache_hot": 0,
        }
        for pn in sorted({int(pn) for pn in (page_nums or [])}):
            if pn in real_pages:
                skipped["canvas_real"] += 1
                continue
            if pn in pending_bg:
                skipped["pending_bg"] += 1
                continue
            if pn in inflight:
                skipped["inflight"] += 1
                continue
            if pn in pending_visible:
                skipped["pending_visible"] += 1
                continue
            cached = PAGE_CACHE.get(path, pn)
            if cached is not None and not cached.isNull():
                skipped["cache_hot"] += 1
                continue
            needed.append(pn)

        print(
            "[DEBUG][review_decision] "
            f"context={context} candidates={self._fmt_review_pages(page_nums)} "
            f"need={self._fmt_review_pages(needed)} "
            f"skip_canvas={skipped['canvas_real']} "
            f"skip_cache={skipped['cache_hot']} "
            f"skip_inflight={skipped['inflight']} "
            f"skip_pending={skipped['pending_visible']} "
            f"skip_bg={skipped['pending_bg']}"
        )
        return needed

    def _on_visible_pages_changed(self, first, last):
        """
        Called 120ms after scroll stops (debounced).
        Renders any visible pages that are still placeholders.
        """
        self._note_user_activity()
        path = getattr(self, "_ondemand_path", None)
        total_pages = getattr(self, "_ondemand_total", 0)

        if not path:
            return

        first = max(0, int(first))
        last = max(first, int(last))
        visible_pages = list(range(first, last + 1))
        prev_visible = set(
            self.__dict__.get("_visible_debug_seen_pages", set()) or set()
        )
        entered_pages = [pn for pn in visible_pages if pn not in prev_visible]
        self._visible_debug_seen_pages = set(visible_pages)
        if entered_pages:
            current_page = visible_pages[len(visible_pages) // 2]
            entered_states = ", ".join(
                f"p.{pn + 1}:{self._review_page_view_state(path, pn)}"
                for pn in entered_pages
            )
            print(
                f"[DEBUG][review_viewport] visible=p.{first + 1}-p.{last + 1} "
                f"current=p.{current_page + 1}:{self._review_page_view_state(path, current_page)} "
                f"entered={entered_states}"
            )

        self._inject_cached_visible_pages(path, visible_pages)
        needed = self._review_pages_needing_render(
            path,
            range(first, last + 1),
            context="visible",
        )

        if not needed:
            return

        if self._ondemand_thread and self._ondemand_thread.isRunning():
            kind = getattr(self, "_ondemand_kind", None)
            if kind in ("background", "priority"):
                print(
                    "[DEBUG][review_ondemand] "
                    f"preempt kind={kind} need={self._fmt_review_pages(needed)}"
                )
                self._stop_ondemand_thread()
                self._ondemand_kind = None
                self._start_visible_page_request(path, needed)
                return

            print(
                "[DEBUG][review_ondemand] "
                f"queue_visible kind={kind} need={self._fmt_review_pages(needed)}"
            )
            self._pending_visible_request = (path, list(needed))
            return

        self._start_visible_page_request(path, needed)

    def _inject_cached_visible_pages(self, path, visible_pages):
        visible_pages = [int(pn) for pn in (visible_pages or [])]
        real_pages = set(self.__dict__.get("_review_canvas_real_pages", set()) or set())
        pending_bg = set((self.__dict__.get("_bg_pending_inserts", {}) or {}).keys())
        inflight = set(
            self.__dict__.get("_review_render_inflight_pages", set()) or set()
        )
        injected = []
        for pn in visible_pages:
            if pn in real_pages or pn in pending_bg or pn in inflight:
                continue
            cached = PAGE_CACHE.get(path, pn)
            if cached is None or cached.isNull():
                continue
            self._debug_review_lazy_page_loaded(
                source="cache",
                page_num=pn,
                pixmap=cached,
                kind="visible_cache",
                canvas_wh=f"{self.canvas.width()}x{self.canvas.height()}px",
            )
            self.canvas.inject_page(pn, cached)
            self.__dict__.setdefault("_review_canvas_real_pages", set()).add(pn)
            self._debug_review_page_injection(
                page_num=pn, injected=True, kind="visible_cache"
            )
            injected.append(pn)
        if injected:
            print(
                "[DEBUG][review_visible_cache] hydrate "
                + ", ".join(f"p.{pn + 1}" for pn in injected)
            )
            self._update_review_page_nav_ui()

    def _start_visible_page_request(self, path, needed):
        self._pending_visible_request = None
        needed = self._review_pages_needing_render(
            path,
            needed,
            context="start_visible",
        )
        if needed:
            print(
                "[DEBUG][review_ondemand] render_request "
                + ", ".join(f"p.{pn + 1}" for pn in needed)
            )
        else:
            print("[DEBUG][review_ondemand] render_request skipped need=none")
            return
        self.__dict__.setdefault("_review_render_inflight_pages", set()).update(needed)
        self._ondemand_kind = "visible"
        self._ondemand_thread = PdfOnDemandThread(
            path, needed, zoom=self._pdf_render_zoom, parent=self
        )
        self._ondemand_requested_pages = set(int(p) for p in needed)
        self._ondemand_thread.page_ready.connect(self._on_page_ready)
        self._ondemand_thread.batch_done.connect(self._on_visible_pages_batch_done)
        self._ondemand_thread.start()

    def _on_visible_pages_batch_done(self, rendered):
        self._note_user_activity()
        requested = set(self.__dict__.pop("_ondemand_requested_pages", set()) or set())
        self.__dict__.setdefault("_review_render_inflight_pages", set()).difference_update(
            requested
        )

        pending = self._pending_visible_request
        self._pending_visible_request = None
        if pending and pending[0] == getattr(self, "_ondemand_path", None):
            path, needed = pending
            fresh_needed = self._review_pages_needing_render(
                path,
                needed,
                context="after_visible",
            )
            if fresh_needed:
                self._start_visible_page_request(path, fresh_needed)
            else:
                self._ondemand_kind = None
        elif getattr(self, "_ondemand_kind", None) == "visible":
            self._ondemand_kind = None
        print(
            "[DEBUG][review_ondemand] "
            f"batch_done requested={self._fmt_review_pages(requested)} "
            f"rendered={self._fmt_review_pages(rendered)} "
            f"pending={self._fmt_review_pages(pending[1] if pending else [])}"
        )

        bg_state = self._background_fill_state
        if (
            bg_state
            and not (self._ondemand_thread and self._ondemand_thread.isRunning())
            and not self._pending_visible_request
        ):
            bg_path, bg_already_rendered, bg_total = bg_state
            if getattr(self, "_canvas_pdf_path", None) == bg_path:
                self._start_background_fill(bg_path, bg_already_rendered, bg_total)

    def _on_page_ready(self, page_num, qpx):
        """
        Slot — called from PdfOnDemandThread.page_ready signal.

        FIX 1: Check _canvas_pdf_path stamp before injecting.
        If user switched to a different card mid-render, the thread's
        path no longer matches the canvas's current PDF — drop the signal.
        This is what caused 'canvas has 0 pages' — canvas was already
        wiped by the new card's load_pages() call.
        """
        current_path = getattr(self, "_canvas_pdf_path", None)
        thread_path = getattr(self, "_ondemand_path", None)
        page_num = int(page_num)
        self.__dict__.setdefault("_review_render_inflight_pages", set()).discard(
            page_num
        )

        if current_path != thread_path:
            self._debug_review_page_injection(
                page_num=page_num,
                injected=False,
                kind=getattr(self, "_ondemand_kind", None) or "visible",
                reason="stale_path",
            )
            return

        canvas_len = len(self.canvas._pages)
        canvas_wh = f"{self.canvas.width()}x{self.canvas.height()}px"

        # Guard: canvas wiped — should not happen after _stop_ondemand_thread fix
        if canvas_len == 0:
            self._debug_review_page_injection(
                page_num=page_num,
                injected=False,
                kind=getattr(self, "_ondemand_kind", None) or "visible",
                reason="canvas_empty",
            )
            return

        cache_px = self._coerce_page_pixmap(qpx)
        if cache_px is None:
            self._debug_review_page_injection(
                page_num=page_num,
                injected=False,
                kind=getattr(self, "_ondemand_kind", None) or "visible",
                reason="null_page",
            )
            return

        load_kind = getattr(self, "_ondemand_kind", None) or "visible"
        self._debug_review_lazy_page_loaded(
            source="render",
            page_num=page_num,
            pixmap=cache_px,
            kind=load_kind,
            canvas_wh=canvas_wh,
        )

        if getattr(self, "_ondemand_kind", None) == "background":
            self._bg_pending_inserts[page_num] = cache_px
            self._debug_review_page_injection(
                page_num=page_num,
                injected=False,
                kind=load_kind,
                reason="queued_pending_insert",
            )
            return
        from PyQt5.QtGui import QPixmap

        if isinstance(cache_px, QPixmap):
            PAGE_CACHE.put(
                thread_path, page_num, cache_px, render_zoom=self._pdf_render_zoom
            )
        self.canvas.inject_page(page_num, cache_px)
        self.__dict__.setdefault("_review_canvas_real_pages", set()).add(page_num)
        self._debug_review_page_injection(
            page_num=page_num,
            injected=True,
            kind=load_kind,
        )
        if load_kind == "visible":
            print(f"[DEBUG][review_ondemand] loaded p.{page_num + 1}")
        self._update_review_page_nav_ui()

    @staticmethod
    def _coerce_page_pixmap(page_obj):
        from PyQt5.QtGui import QImage, QPixmap

        if isinstance(page_obj, QPixmap):
            return page_obj if not page_obj.isNull() else None
        if isinstance(page_obj, QImage):
            px = QPixmap.fromImage(page_obj)
            return px if not px.isNull() else None
        if page_obj is not None and hasattr(page_obj, "isNull"):
            try:
                is_null = page_obj.isNull()
                if isinstance(is_null, bool) and is_null:
                    return None
                return page_obj
            except Exception:
                return page_obj
        return None

    def _debug_review_lazy_page_loaded(
        self, source: str, page_num: int, pixmap, kind: str = "", canvas_wh: str = ""
    ):
        if self.__dict__.get("_review_lazy_trace_suspended", False):
            return
        page_num = int(page_num)
        emoji = "⚡" if str(source).strip().lower() == "cache" else "👀"
        print(f"[DEBUG][review_lazy] {emoji} p.{page_num + 1}")

    def _review_page_view_state(self, path: str, page_num: int) -> str:
        page_num = int(page_num)
        if page_num in set(
            self.__dict__.get("_review_canvas_real_pages", set()) or set()
        ):
            return "canvas_real"
        if page_num in set((self.__dict__.get("_bg_pending_inserts", {}) or {}).keys()):
            return "rendered_waiting_inject"
        pending = self.__dict__.get("_pending_visible_request")
        if pending and pending[0] == path and page_num in set(pending[1] or []):
            return "queued_visible_render"
        if page_num in set(
            self.__dict__.get("_review_render_inflight_pages", set()) or set()
        ):
            return "rendering"
        cached = PAGE_CACHE.get(path, page_num)
        if cached is not None and not cached.isNull():
            return "cache_hot_canvas_gray"
        pages = getattr(getattr(self, "canvas", None), "_pages", None) or []
        if (
            0 <= page_num < len(pages)
            and pages[page_num] is not None
            and not pages[page_num].isNull()
        ):
            return "placeholder_gray"
        return "canvas_missing"

    def _debug_review_page_injection(
        self, page_num: int, injected: bool, kind: str = "", reason: str = ""
    ):
        page_num = int(page_num)
        status = "yes" if injected else "no"
        parts = [f"[DEBUG][review_inject] p.{page_num + 1} injected={status}"]
        if kind:
            parts.append(f"kind={kind}")
        if reason:
            parts.append(f"reason={reason}")
        print(" ".join(parts))

    def _debug_review_lazy_pages_loaded(self, source: str, page_nums):
        for page_num in page_nums or []:
            self._debug_review_lazy_page_loaded(
                source=source, page_num=page_num, pixmap=None
            )

    def _stop_ondemand_thread(self):
        """
        Safely stop any running PdfOnDemandThread.

        ── BUG FIX (v20-patch) ──────────────────────────────────────────────────
        BEFORE (broken):
            if thread running  → stop it
            else               → canvas.load_pixmap(QPixmap())   ← WIPED _pages!

        The else branch fired every time _stop_ondemand_thread() was called when
        no thread was running yet — e.g. the very first call from
        _start_background_fill() right after skeleton load.
        load_pixmap(null-QPixmap) sets _pages=[] and resizes canvas to 1×1 px,
        so every subsequent inject_page() hit "out of range (canvas has 0 pages)".

        FIX: simply remove the else branch. Callers that need UI resets
        (_show_overlay, _rating_frame.hide) already do so themselves.
        ─────────────────────────────────────────────────────────────────────────
        """
        t = getattr(self, "_ondemand_thread", None)
        if t and t.isRunning():
            t.stop()
            t.quit()
            t.wait(400)
        requested = set(self.__dict__.pop("_ondemand_requested_pages", set()) or set())
        if requested:
            self.__dict__.setdefault(
                "_review_render_inflight_pages", set()
            ).difference_update(requested)
        # Always clear the reference so the next start gets a fresh thread
        self._ondemand_thread = None

    def _apply_canvas(self, card, box_idx, px):
        """Pixmap + boxes canvas pe set karo — sync aur async dono paths use karte hain."""
        self._current_pixmap = px
        _pdf_path = resolve_asset_path(card.get("pdf_path", ""))
        # [PIXMAP REGISTRY] ReviewWindow ka current pixmap + canvas track karo
        from cache_manager import PIXMAP_REGISTRY

        PIXMAP_REGISTRY.register(
            f"review_current_{id(self)}", self, "_current_pixmap", _pdf_path
        )
        self.canvas._current_pdf_path = _pdf_path
        boxes = card.get("boxes", [])
        self.canvas.load_pixmap(px)
        if isinstance(box_idx, tuple) and box_idx[0] == "group":
            gid = box_idx[1]
            display_boxes = [
                {
                    **{
                        k: b[k]
                        for k in (
                            "rect",
                            "label",
                            "shape",
                            "angle",
                            "group_id",
                            "box_id",
                        )
                        if k in b
                    },
                    "rect": b["rect"],
                    "label": b.get("label", ""),
                    "revealed": False,
                }
                for b in boxes
            ]
            self.canvas.set_boxes_with_state(display_boxes)
            self.canvas.set_target_box(-1)
            self.canvas.set_mode("review")
            self.canvas.set_target_group(gid)
        elif box_idx is None:
            self.canvas.set_boxes(boxes)
            self.canvas.set_target_box(-1)
            self.canvas.set_mode("review")
        else:
            display_boxes = [
                {
                    "rect": b["rect"],
                    "label": b.get("label", ""),
                    "shape": b.get("shape", "rect"),
                    "angle": b.get("angle", 0.0),
                    "group_id": b.get("group_id", ""),
                    "revealed": False,
                }
                for i, b in enumerate(boxes)
            ]
            self.canvas.set_boxes_with_state(display_boxes)
            self.canvas.set_target_box(box_idx)
            self.canvas.set_mode("review")

        # FIX: retain user-set zoom for image cards too
        from PyQt5.QtCore import QTimer

        def _apply_zoom_and_center_img():
            if self._user_zoom_scale is not None:
                self.canvas._scale = self._user_zoom_scale
                self.canvas._on_zoom()
            else:
                self._zoom_fit()
            self._center_on_target()
            self._update_review_page_nav_ui()

        QTimer.singleShot(0, _apply_zoom_and_center_img)

    def _apply_canvas_pages(self, card, box_idx, pages):
        """File: anki_occlusion_v19.py -> Class: ReviewScreen"""
        path = resolve_asset_path(card.get("pdf_path", ""))
        self._canvas_pdf_path = path
        self.canvas._current_pdf_path = path
        if hasattr(self.canvas, "clear_peek_target"):
            self.canvas.clear_peek_target()

        # 1. Load ALL pages
        self.canvas.load_pages(pages)

        # 2. Re-register with Registry for deep cards
        from cache_manager import MASK_REGISTRY

        MASK_REGISTRY.register(path, self.canvas)

        # 3. set_mode FIRST so it doesn't wipe revealed state set below
        self.canvas.set_mode("review")

        # 4. Setup boxes state (must come AFTER set_mode)
        boxes = card.get("boxes", [])
        source_box_zoom = card.get("_pdf_box_render_zoom", PDF_LEGACY_BOX_ZOOM)
        if path and boxes:
            boxes = self._adapt_review_boxes(card, path)
            self._pdf_quality_debug(
                "box_remap",
                source_zoom=source_box_zoom,
                target_zoom=self._pdf_render_zoom,
                boxes=len(boxes),
            )
        if isinstance(box_idx, tuple) and box_idx[0] == "group":
            gid = box_idx[1]
            display_boxes = [{**b, "revealed": False} for b in boxes]
            self.canvas.set_boxes_with_state(display_boxes)
            self.canvas.set_target_group(gid)
        else:
            display_boxes = [{**b, "revealed": False} for i, b in enumerate(boxes)]
            self.canvas.set_boxes_with_state(display_boxes)
            self.canvas.set_target_box(box_idx if box_idx is not None else -1)

        # 5. Always reset UI state — Show Answer bar visible, rating hidden
        self._show_overlay(self._reveal_bar)
        self._rating_frame.hide()

        # 6. Zoom fit + center (deferred so viewport geometry is final)
        from PyQt5.QtCore import QTimer

        if self._pending_reload_page is not None:
            reload_page = self._pending_reload_page
            self._pending_reload_page = None
            QTimer.singleShot(
                0,
                lambda pg=reload_page: (
                    self._zoom_fit(),
                    self.canvas.scroll_to_page(pg, self._canvas_scroll),
                ),
            )
        else:
            # FIX: retain user-set zoom across cards
            def _apply_zoom_and_center():
                if self._user_zoom_scale is not None:
                    self.canvas._scale = self._user_zoom_scale
                    self.canvas._on_zoom()
                else:
                    self._zoom_fit()
                self._center_on_target()

            QTimer.singleShot(0, _apply_zoom_and_center)
        QTimer.singleShot(0, self._update_review_page_nav_ui)

        # 7. Rebuild queue now that _page_tops is populated with real page positions
        QTimer.singleShot(50, self._rebuild_queue)
        # 8. Force a visible-page pass after the viewport settles so already-cached
        #    pages show immediately when returning to review.
        QTimer.singleShot(120, self._canvas_scroll._emit_visible_pages)

    def _start_review_pdf_thread(self, card, box_idx):
        path = resolve_asset_path(card.get("pdf_path", ""))
        if (
            hasattr(self, "_pdf_loader_thread")
            and self._pdf_loader_thread
            and self._pdf_loader_thread.isRunning()
        ):
            self._pdf_loader_thread.stop()
            self._pdf_loader_thread.quit()
            self._pdf_loader_thread.wait(300)

        self._pdf_render_zoom = choose_pdf_render_zoom(get_pdf_page_count(path))
        profile_reset = ensure_pdf_cache_profile(path, self._pdf_render_zoom)
        self._pdf_quality_debug(
            "fallback_loader",
            pages=get_pdf_page_count(path),
            zoom=self._pdf_render_zoom,
            reset_cache=profile_reset,
        )
        self._pdf_loader_thread = PdfLoaderThread(
            path, zoom=self._pdf_render_zoom, parent=self
        )
        self._pending_review_card = card
        self._pending_review_box_idx = box_idx
        self._review_loader_logged_pages = 0

        # [FIX] Show first chunk instantly as pages arrive
        self._pdf_loader_thread.pages_ready.connect(self._on_review_pages_chunk)
        self._pdf_loader_thread.done.connect(self._on_review_pages_ready)
        self._pdf_loader_thread.start()

        # Show loading toast immediately
        total = get_pdf_page_count(path) or "?"
        self.canvas._show_toast(f"⏳ Loading PDF... 0/{total} pages")
        self._pdf_total_pages = total

    def _coerce_loader_pages_to_pixmaps(self, path: str, pages: list):
        out = []
        for page_num, page_obj in enumerate(pages or []):
            px = self._coerce_page_pixmap(page_obj)
            if px is not None:
                PAGE_CACHE.put(
                    path,
                    page_num,
                    px,
                    render_zoom=self._pdf_render_zoom,
                )
            out.append(px)
        return out

    def _on_review_pages_chunk(self, pages, loaded, total):
        """Show first pages as soon as first chunk arrives — don't wait for full load."""
        card = self._pending_review_card
        box_idx = self._pending_review_box_idx
        path = resolve_asset_path(card.get("pdf_path", ""))
        pages = self._coerce_loader_pages_to_pixmaps(path, pages)
        start_idx = int(getattr(self, "_review_loader_logged_pages", 0) or 0)
        end_idx = min(int(loaded or 0), len(pages or []))
        if end_idx > start_idx:
            self._debug_review_lazy_pages_loaded(
                source="render", page_nums=range(start_idx, end_idx)
            )
            self._review_loader_logged_pages = end_idx
        if pages:
            self._apply_canvas_pages(card, box_idx, pages)
            self._review_canvas_real_pages = set(range(len(pages)))
            self._review_render_inflight_pages.clear()
        self.canvas._show_toast(f"⏳ Loading PDF... {loaded}/{total} pages")

    def _on_review_pages_ready(self, pages, err):
        if not pages or err:
            return
        card = self._pending_review_card
        box_idx = self._pending_review_box_idx
        path = resolve_asset_path(card.get("pdf_path", ""))
        pages = self._coerce_loader_pages_to_pixmaps(path, pages)
        start_idx = int(getattr(self, "_review_loader_logged_pages", 0) or 0)
        end_idx = len(pages or [])
        if end_idx > start_idx:
            self._debug_review_lazy_pages_loaded(
                source="render", page_nums=range(start_idx, end_idx)
            )
            self._review_loader_logged_pages = end_idx
        self._apply_canvas_pages(card, box_idx, pages)
        self._review_canvas_real_pages = set(range(len(pages)))
        self._review_render_inflight_pages.clear()
        self.canvas._show_toast(f"✅ PDF loaded — {len(pages)} pages")

    def _finish(self):
        # [BUG 1 FIX] Check if any learning/relearn items are still pending
        # (e.g. m1 got Again → due in 1min, but m2/m3 finished early)
        # If yes, wait and re-check instead of ending the session.
        pending_learning = [
            (i, sm2_obj)
            for i, (_, _, sm2_obj) in enumerate(self._items)
            if sm2_obj.get("sched_state") in ("learning", "relearn")
        ]
        if pending_learning:
            # Find the earliest due learning item
            earliest_idx, earliest_obj = min(
                pending_learning, key=lambda x: x[1].get("sm2_due", "")
            )
            due_str = earliest_obj.get("sm2_due", "")
            try:
                from datetime import datetime as _dt

                due_dt = _dt.fromisoformat(due_str)
                wait_ms = max(0, int((_dt.now() - due_dt).total_seconds() * -1000))
            except Exception:
                wait_ms = 0
            if wait_ms > 0:
                # Show waiting state — re-check when earliest card becomes due
                self._show_waiting_state(wait_ms, len(pending_learning))
                return
            else:
                # Due time already passed — jump to that item directly
                self._idx = earliest_idx
                self._load_item()
                return

        self.prog.setValue(len(self._items))
        self._show_session_summary()

    def _show_session_summary(self):
        """Session khatam — stats dialog dikhao."""
        dojo = _is_dojo()
        D = DOJO

        bg = D["bg"] if dojo else C_BG
        surface = D["surface"] if dojo else C_SURFACE
        card = D["card"] if dojo else C_CARD
        accent = D["accent"] if dojo else C_ACCENT
        green = D["green"] if dojo else C_GREEN
        red = D["red"] if dojo else C_RED
        yellow = D["yellow"] if dojo else C_YELLOW
        text = D["text"] if dojo else C_TEXT
        subtext = D["subtext"] if dojo else C_SUBTEXT
        border = D["border"] if dojo else C_BORDER
        font = D["font"] if dojo else "'Segoe UI'"

        again = hard = good = easy = perfect = 0
        for _, _, sm2_obj in self._items:
            q = sm2_obj.get("sm2_last_quality", -1)
            if q == 1:
                again += 1
            elif q == 3:
                hard += 1
            elif q == 4:
                good += 1
            elif q == 5:
                easy += 1
            elif q == 6:
                perfect += 1

        total = again + hard + good + easy + perfect
        retention = round((good + easy + perfect) / total * 100) if total else 0

        dlg = QDialog(self)
        dlg.setWindowTitle("Mission Complete" if dojo else "Session Complete")
        dlg.setFixedSize(360, 380 if dojo else 345)
        if dojo:
            dlg.setStyleSheet(
                f"QDialog{{background:{bg};border:1px solid {accent};}}"
                f"QWidget{{background:{bg};}}"
                f"QLabel{{background:transparent;}}"
            )
        else:
            dlg.setStyleSheet(f"QDialog{{background:{bg};}}")
        L = QVBoxLayout(dlg)
        L.setContentsMargins(24, 24, 24, 24)
        L.setSpacing(12)

        # Title
        if dojo:
            title = QLabel("🥷  MISSION COMPLETE")
            title.setFont(QFont(font, 12, QFont.Bold))
            title.setAlignment(Qt.AlignCenter)
            title.setStyleSheet(
                f"color:{accent};background:transparent;"
                f"letter-spacing:3px;font-family:{font};"
                f"border-bottom:1px solid {border};padding-bottom:8px;"
            )
        else:
            title = QLabel("🎉  Session Complete")
            title.setFont(QFont("Segoe UI", 15, QFont.Bold))
            title.setAlignment(Qt.AlignCenter)
            title.setStyleSheet(f"color:{accent};background:transparent;")
        L.addWidget(title)

        # Retention bar
        bar_w = QWidget()
        bar_l = QHBoxLayout(bar_w)
        bar_l.setContentsMargins(0, 0, 0, 0)
        bar_l.setSpacing(0)
        ret_colors = [
            (again, D["red"] if dojo else C_RED),
            (hard, "#FF8C00" if dojo else "#E08030"),
            (good, D["green"] if dojo else C_GREEN),
            (easy, D["yellow"] if dojo else C_YELLOW),
            (perfect, D["accent2"] if dojo else C_GROUP),
        ]
        for count, color in ret_colors:
            if count and total:
                seg = QFrame()
                seg.setFixedHeight(6 if dojo else 10)
                seg.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
                seg.setStyleSheet(f"background:{color};border-radius:0px;")
                bar_l.addWidget(seg, stretch=count)
        L.addWidget(bar_w)

        # Stats rows
        def _stat_row(label, value, color):
            row = QWidget()
            row.setStyleSheet("background:transparent;")
            rl = QHBoxLayout(row)
            rl.setContentsMargins(0, 0, 0, 0)
            lbl = QLabel(label)
            if dojo:
                lbl.setStyleSheet(
                    f"color:{subtext};font-size:8px;background:transparent;"
                    f"font-family:{font};letter-spacing:1px;"
                )
            else:
                lbl.setStyleSheet(
                    f"color:{subtext};font-size:12px;background:transparent;"
                )
            val = QLabel(str(value))
            if dojo:
                val.setStyleSheet(
                    f"color:{color};font-size:13px;font-weight:bold;"
                    f"background:transparent;font-family:{font};"
                )
            else:
                val.setStyleSheet(
                    f"color:{color};font-size:13px;font-weight:bold;background:transparent;"
                )
            val.setAlignment(Qt.AlignRight)
            rl.addWidget(lbl)
            rl.addWidget(val)
            return row

        L.addWidget(
            _stat_row(
                "🔁  AGAIN" if dojo else "🔁  Again", again, D["red"] if dojo else C_RED
            )
        )
        L.addWidget(
            _stat_row(
                "😓  HARD" if dojo else "😓  Hard",
                hard,
                "#FF8C00" if dojo else "#E08030",
            )
        )
        L.addWidget(
            _stat_row(
                "✅  GOOD" if dojo else "✅  Good",
                good,
                D["green"] if dojo else C_GREEN,
            )
        )
        L.addWidget(
            _stat_row(
                "⚡  EASY" if dojo else "⚡  Easy",
                easy,
                D["yellow"] if dojo else C_YELLOW,
            )
        )
        L.addWidget(
            _stat_row(
                "⭐  PERFECT" if dojo else "⭐  Perfect",
                perfect,
                D["accent2"] if dojo else C_GROUP,
            )
        )

        sep = QFrame()
        sep.setFrameShape(QFrame.HLine)
        sep.setStyleSheet(f"background:{border};")
        sep.setFixedHeight(1)
        L.addWidget(sep)

        ret_color = green if retention >= 80 else yellow if retention >= 60 else red
        L.addWidget(
            _stat_row("RETENTION" if dojo else "Retention", f"{retention}%", ret_color)
        )
        L.addWidget(
            _stat_row("TOTAL REVIEWED" if dojo else "Total reviewed", self._done, text)
        )

        if self._stimer:
            L.addWidget(
                _stat_row(
                    "⏱  TIME SPENT" if dojo else "⏱  Time spent",
                    self._stimer.elapsed_str(),
                    subtext,
                )
            )

        # Ninja motivational quote for dojo
        if dojo and retention >= 80:
            q_lbl = QLabel('"COWABUNGA! EXCELLENT WORK, NINJA."')
            q_lbl.setAlignment(Qt.AlignCenter)
            q_lbl.setWordWrap(True)
            q_lbl.setStyleSheet(
                f"color:{accent};font-size:7px;font-family:{font};"
                f"letter-spacing:1px;background:transparent;"
            )
            L.addWidget(q_lbl)

        # Close button
        btn = QPushButton("✕  CLOSE" if dojo else "Close  ✓")
        if dojo:
            btn.setStyleSheet(
                f"background:{accent};color:{bg};border:none;border-radius:2px;"
                f"padding:8px 24px;font-size:9px;font-weight:900;"
                f"font-family:{font};letter-spacing:1px;"
            )
        else:
            btn.setStyleSheet(
                f"background:{accent};color:white;border:none;border-radius:8px;"
                f"padding:8px 24px;font-size:13px;font-weight:bold;"
            )
        btn.clicked.connect(dlg.accept)
        L.addWidget(btn, alignment=Qt.AlignCenter)

        dlg.exec_()
        self.finished.emit()

    def _show_waiting_state(self, wait_ms: int, pending_count: int):
        """Learning cards pending hain — countdown show karo, session end mat karo."""
        secs = max(1, wait_ms // 1000)
        self._reveal_bar.hide()
        self._rating_frame.hide()
        # _wait_bar is a proper QFrame already in the layout (created in _setup_ui)
        mins, s = divmod(secs, 60)
        self._wait_lbl_countdown.setText(f"next card in  {mins}m {s:02d}s")
        self._wait_lbl_count.setText(f"⏳  {pending_count} card(s) still in learning")
        self._wait_bar.show()
        QTimer.singleShot(1000, self._check_learning_due)


# ═══════════════════════════════════════════════════════════════════════════════
